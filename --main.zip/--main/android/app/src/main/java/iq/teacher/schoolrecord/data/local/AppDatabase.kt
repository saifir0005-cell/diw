package iq.teacher.schoolrecord.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "classes")
data class ClassEntity(
    @PrimaryKey val id: String,
    val name: String,
    val academicYear: String,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sections",
    foreignKeys = [
        ForeignKey(
            entity = ClassEntity::class,
            parentColumns = ["id"],
            childColumns = ["classId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SectionEntity(
    @PrimaryKey val id: String,
    val classId: String,
    val name: String,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "students",
    foreignKeys = [
        ForeignKey(
            entity = SectionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sectionId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class StudentEntity(
    @PrimaryKey val id: String,
    val studentNumber: String,
    val fullName: String,
    val classId: String,
    val sectionId: String,
    val notes: String = "",
    val status: String = "مستمر",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "art_grades")
data class DetailedArtGradeEntity(
    @PrimaryKey val studentId: String,
    val classId: String,
    val sectionId: String,
    val academicYear: String,
    val oralM1: Double? = null,
    val examM1: Double? = null,
    val avgM1: Double? = null,
    val oralM2: Double? = null,
    val examM2: Double? = null,
    val avgM2: Double? = null,
    val sem1Pursuit: Double? = null,
    val midYearExam: Double? = null,
    val oralM3: Double? = null,
    val examM3: Double? = null,
    val avgM3: Double? = null,
    val oralM4: Double? = null,
    val examM4: Double? = null,
    val avgM4: Double? = null,
    val sem2Pursuit: Double? = null,
    val annualPursuit: Double? = null,
    val finalExam: Double? = null,
    val finalGrade: Double? = null,
    val resultStatus: String = "غير مكتمل",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class AttendanceEntity(
    @PrimaryKey val id: String,
    val studentId: String,
    val classId: String,
    val sectionId: String,
    val date: String,
    val status: String, // حاضر, غائب, مجاز, متأخر
    val reason: String = "",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface SchoolDao {
    @Query("SELECT * FROM classes WHERE isArchived = 0")
    fun getAllClasses(): Flow<List<ClassEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(classEntity: ClassEntity)

    @Query("SELECT * FROM sections WHERE classId = :classId AND isArchived = 0")
    fun getSectionsForClass(classId: String): Flow<List<SectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSection(sectionEntity: SectionEntity)

    @Query("SELECT * FROM students WHERE sectionId = :sectionId AND isArchived = 0")
    fun getStudentsForSection(sectionId: String): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>)

    @Query("SELECT * FROM art_grades WHERE studentId = :studentId")
    suspend fun getGradeForStudent(studentId: String): DetailedArtGradeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGrade(grade: DetailedArtGradeEntity)

    @Query("SELECT * FROM attendance WHERE classId = :classId AND sectionId = :sectionId AND date = :date")
    fun getAttendanceForDate(classId: String, sectionId: String, date: String): Flow<List<AttendanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(records: List<AttendanceEntity>)
}

@Database(
    entities = [
        ClassEntity::class,
        SectionEntity::class,
        StudentEntity::class,
        DetailedArtGradeEntity::class,
        AttendanceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao
}
