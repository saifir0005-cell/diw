package iq.teacher.schoolrecord

import iq.teacher.schoolrecord.domain.engine.IraqiGradingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit Tests for Iraqi Intermediate School Art Education Grading Rules
 */
class GradingFormulaTest {

    @Test
    fun testMonthlyAverageCalculation() {
        val oral = 46.0
        val exam = 44.0
        val avg = IraqiGradingEngine.calculateMonthlyAverage(oral, exam)
        assertEquals(45.0, avg ?: 0.0, 0.001)
    }

    @Test
    fun testMissingGradeReturnsNullNeverZero() {
        // Critical requirement: Never convert a blank grade into zero!
        val oral = 48.0
        val exam: Double? = null
        val avg = IraqiGradingEngine.calculateMonthlyAverage(oral, exam)
        assertNull("Missing grade must return null, not 0.0", avg)
    }

    @Test
    fun testSemesterPursuitCalculation() {
        val m1 = 45.0
        val m2 = 47.0
        val pursuit = IraqiGradingEngine.calculateSemesterPursuit(m1, m2)
        assertEquals(46.0, pursuit ?: 0.0, 0.001)
    }

    @Test
    fun testAnnualPursuitCalculation() {
        // Annual pursuit = (First Semester Pursuit + Second Semester Pursuit + Midyear) / 3
        val sem1 = 45.0
        val sem2 = 45.0
        val midYear = 90.0
        val annual = IraqiGradingEngine.calculateAnnualPursuit(sem1, sem2, midYear)
        assertEquals(60.0, annual ?: 0.0, 0.001)
    }

    @Test
    fun testFinalGradeAndPassingStatus() {
        val annualPursuit = 60.0
        val finalExam = 70.0
        val finalGrade = IraqiGradingEngine.calculateFinalGrade(annualPursuit, finalExam)
        assertEquals(65.0, finalGrade ?: 0.0, 0.001)

        assertTrue(IraqiGradingEngine.isPassing(finalGrade, 50.0))
        assertFalse(IraqiGradingEngine.isPassing(49.0, 50.0))
    }
}
