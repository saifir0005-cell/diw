import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  TeacherProfile,
  ClassGrade,
  Section,
  Student,
  AttendanceRecord,
  DetailedArtGradeRecord,
  GradingConfig,
  MainNavScreen,
  AttendanceStatus,
  StudentMonthlyCompliance,
  NonComplianceCheck,
  GiftedStudent,
  TalentDomain,
} from '../types';
import {
  recalculateStudentRecord,
  applyDeductionsToRecord,
} from '../utils/gradingEngine';
import { getTodayDateString } from '../utils/dateUtils';

interface TeacherAppContextType {
  profile: TeacherProfile;
  setProfile: (p: TeacherProfile) => void;
  updateProfile: (updates: Partial<TeacherProfile>) => void;

  gradingConfig: GradingConfig;
  setGradingConfig: (c: GradingConfig) => void;
  updateGradingConfig: (updates: Partial<GradingConfig>) => void;

  classes: ClassGrade[];
  addClass: (name: string) => string;
  updateClass: (id: string, name: string) => void;
  archiveClass: (id: string) => void;
  deleteClass: (id: string) => void;

  sections: Section[];
  addSection: (classId: string, name: string) => string;
  updateSection: (id: string, name: string) => void;
  archiveSection: (id: string) => void;
  deleteSection: (id: string) => void;

  students: Student[];
  addStudent: (fullName: string, classId: string, sectionId: string, notes?: string) => string;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  archiveStudent: (id: string) => void;
  deleteStudent: (id: string) => void;
  importStudentsCSV: (csvText: string, classId: string, sectionId: string) => { added: number; duplicates: number };

  grades: Record<string, DetailedArtGradeRecord>; // studentId -> DetailedArtGradeRecord
  updateGradeField: (studentId: string, field: keyof DetailedArtGradeRecord, value: any) => void;
  batchSaveGrades: (updatedGrades: DetailedArtGradeRecord[]) => void;
  getStudentGrade: (studentId: string) => DetailedArtGradeRecord;

  attendance: AttendanceRecord[];
  saveDayAttendance: (
    classId: string,
    sectionId: string,
    date: string,
    records: { studentId: string; status: AttendanceStatus; reason?: string; notes?: string }[]
  ) => void;
  getAttendanceForDate: (classId: string, sectionId: string, date: string) => Record<string, AttendanceRecord>;
  getStudentAttendanceStats: (studentId: string) => { totalAbsences: number; excused: number; late: number; present: number };

  // 1. Non-Compliance (قسم غير الملتزم)
  compliances: Record<string, StudentMonthlyCompliance>; // key `${studentId}_m${monthIndex}`
  toggleNonComplianceCheck: (
    studentId: string,
    monthIndex: 1 | 2 | 3 | 4,
    checkIndex: 1 | 2 | 3 | 4,
    isNonCompliant?: boolean,
    reason?: string,
    date?: string
  ) => void;
  getStudentMonthlyCompliance: (studentId: string, monthIndex: 1 | 2 | 3 | 4) => StudentMonthlyCompliance;
  getAllStudentCompliances: (studentId: string) => StudentMonthlyCompliance[];

  // 5. Gifted Students (قسم الطلبة الموهوبين)
  giftedStudents: Record<string, GiftedStudent>; // key: studentId
  addGiftedStudent: (data: {
    studentId: string;
    talentDomain: string;
    discoveryDate: string;
    teacherNotes?: string;
    participations?: string;
  }) => void;
  updateGiftedStudent: (studentId: string, updates: Partial<GiftedStudent>) => void;
  removeGiftedStudent: (studentId: string) => void;
  isStudentGifted: (studentId: string) => boolean;

  // Navigation and active selection
  activeScreen: MainNavScreen;
  setActiveScreen: (screen: MainNavScreen) => void;
  selectedClassId: string;
  setSelectedClassId: (id: string) => void;
  selectedSectionId: string;
  setSelectedSectionId: (id: string) => void;
  selectedDate: string;
  setSelectedDate: (date: string) => void;

  // Backup & Restore
  exportFullBackupJSON: () => string;
  importFullBackupJSON: (jsonText: string) => { success: boolean; message: string };
  resetAppToDefaults: () => void;
  seedDemoTeacherData: () => void;
}

const TeacherAppContext = createContext<TeacherAppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PROFILE: 'ali_teacher_profile_v1',
  CONFIG: 'ali_teacher_grading_config_v1',
  CLASSES: 'ali_teacher_classes_v1',
  SECTIONS: 'ali_teacher_sections_v1',
  STUDENTS: 'ali_teacher_students_v1',
  GRADES: 'ali_teacher_grades_v1',
  ATTENDANCE: 'ali_teacher_attendance_v1',
  COMPLIANCE: 'ali_teacher_compliance_v1',
  GIFTED: 'ali_teacher_gifted_v1',
};

const DEFAULT_PROFILE: TeacherProfile = {
  teacherName: 'الأستاذ علي الهنيدي',
  schoolName: 'ثانوية الديوانية للمتميزين',
  subject: 'التربية الفنية',
  academicYear: '2026–2027',
};

const DEFAULT_CONFIG: GradingConfig = {
  academicYear: '2026–2027',
  minPassingGrade: 50,
  roundingRule: 'standard',
  treatBlankAsZero: false,
  formulaMode: 'verified_official',
  highAchievementThreshold: 85,
  mediumAchievementThreshold: 60,
};

function createDefaultMonthlyCompliance(studentId: string, monthIndex: 1 | 2 | 3 | 4): StudentMonthlyCompliance {
  return {
    id: `${studentId}_m${monthIndex}`,
    studentId,
    monthIndex,
    checks: [
      { checkIndex: 1, isNonCompliant: false },
      { checkIndex: 2, isNonCompliant: false },
      { checkIndex: 3, isNonCompliant: false },
      { checkIndex: 4, isNonCompliant: false },
    ],
    totalDeduction: 0,
    notes: '',
    updatedAt: new Date().toISOString(),
  };
}

export const TeacherAppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Profile State
  const [profile, setProfileState] = useState<TeacherProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  // 2. Grading Config
  const [gradingConfig, setGradingConfigState] = useState<GradingConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_CONFIG,
          ...parsed,
        };
      }
      return DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });

  // 3. Classes
  const [classes, setClasses] = useState<ClassGrade[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CLASSES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 4. Sections
  const [sections, setSections] = useState<Section[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SECTIONS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 5. Students
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 6. Detailed Art Grades
  const [grades, setGrades] = useState<Record<string, DetailedArtGradeRecord>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GRADES);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // 7. Attendance Records
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 8. Non-Compliance Records
  const [compliances, setCompliances] = useState<Record<string, StudentMonthlyCompliance>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPLIANCE);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // 9. Gifted Students Records
  const [giftedStudents, setGiftedStudents] = useState<Record<string, GiftedStudent>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GIFTED);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Navigation State
  const [activeScreen, setActiveScreen] = useState<MainNavScreen>('dashboard');
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // Auto-sync to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(gradingConfig));
  }, [gradingConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CLASSES, JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(sections));
  }, [sections]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GRADES, JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPLIANCE, JSON.stringify(compliances));
  }, [compliances]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GIFTED, JSON.stringify(giftedStudents));
  }, [giftedStudents]);

  // First time auto-seed so the teacher is greeted with realistic demo data
  useEffect(() => {
    const initialized = localStorage.getItem('ali_teacher_initialized_v3');
    if (!initialized && classes.length === 0) {
      localStorage.setItem('ali_teacher_initialized_v3', 'true');
      seedDemoTeacherData();
    }
  }, []);

  // Keep cascade selection in sync
  useEffect(() => {
    const unarchivedClasses = classes.filter((c) => !c.archived);
    if (unarchivedClasses.length > 0) {
      if (!selectedClassId || !unarchivedClasses.some((c) => c.id === selectedClassId)) {
        setSelectedClassId(unarchivedClasses[0].id);
      }
    } else {
      setSelectedClassId('');
      setSelectedSectionId('');
    }
  }, [classes, selectedClassId]);

  useEffect(() => {
    if (selectedClassId) {
      const classSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);
      if (classSections.length > 0) {
        if (!selectedSectionId || !classSections.some((s) => s.id === selectedSectionId)) {
          setSelectedSectionId(classSections[0].id);
        }
      } else {
        setSelectedSectionId('');
      }
    }
  }, [selectedClassId, sections, selectedSectionId]);

  // Profile operations
  const setProfile = (p: TeacherProfile) => setProfileState(p);
  const updateProfile = (updates: Partial<TeacherProfile>) => {
    setProfileState((prev) => ({ ...prev, ...updates }));
  };

  // Config operations
  const setGradingConfig = (c: GradingConfig) => setGradingConfigState(c);
  const updateGradingConfig = (updates: Partial<GradingConfig>) => {
    setGradingConfigState((prev) => {
      const updated = { ...prev, ...updates };
      const recalculatedGrades: Record<string, DetailedArtGradeRecord> = {};
      Object.entries(grades).forEach(([stdId, record]) => {
        recalculatedGrades[stdId] = applyDeductionsToRecord(record, compliances, updated);
      });
      setGrades(recalculatedGrades);
      return updated;
    });
  };

  // Class operations
  const addClass = (name: string): string => {
    const id = `cls_${Date.now()}`;
    const now = new Date().toISOString();
    const newClass: ClassGrade = {
      id,
      name: name.trim(),
      academicYear: profile.academicYear,
      archived: false,
      createdAt: now,
      updatedAt: now,
    };
    setClasses((prev) => [...prev, newClass]);
    if (!selectedClassId) setSelectedClassId(id);
    return id;
  };

  const updateClass = (id: string, name: string) => {
    const now = new Date().toISOString();
    setClasses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, name: name.trim(), updatedAt: now } : c))
    );
  };

  const archiveClass = (id: string) => {
    setClasses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, archived: !c.archived } : c))
    );
  };

  const deleteClass = (id: string) => {
    setClasses((prev) => prev.filter((c) => c.id !== id));
    setSections((prev) => prev.filter((s) => s.classId !== id));
    setStudents((prev) => prev.filter((std) => std.classId !== id));
  };

  // Section operations
  const addSection = (classId: string, name: string): string => {
    const id = `sec_${Date.now()}`;
    const now = new Date().toISOString();
    const newSec: Section = {
      id,
      classId,
      name: name.trim(),
      archived: false,
      createdAt: now,
      updatedAt: now,
    };
    setSections((prev) => [...prev, newSec]);
    if (!selectedSectionId) setSelectedSectionId(id);
    return id;
  };

  const updateSection = (id: string, name: string) => {
    const now = new Date().toISOString();
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, name: name.trim(), updatedAt: now } : s))
    );
  };

  const archiveSection = (id: string) => {
    setSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, archived: !s.archived } : s))
    );
  };

  const deleteSection = (id: string) => {
    setSections((prev) => prev.filter((s) => s.id !== id));
    setStudents((prev) => prev.filter((std) => std.sectionId !== id));
  };

  // Student operations
  const generateStudentNumber = (): string => {
    const yearPrefix = profile.academicYear.slice(0, 4);
    const nextSeq = String(students.length + 1).padStart(3, '0');
    return `${yearPrefix}${nextSeq}`;
  };

  const addStudent = (
    fullName: string,
    classId: string,
    sectionId: string,
    notes?: string
  ): string => {
    const id = `std_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const studentNumber = generateStudentNumber();
    const now = new Date().toISOString();

    const newStudent: Student = {
      id,
      studentNumber,
      fullName: fullName.trim(),
      classId,
      sectionId,
      notes: notes?.trim() || '',
      status: 'مستمر',
      archived: false,
      createdAt: now,
      updatedAt: now,
    };

    setStudents((prev) => [...prev, newStudent]);

    const emptyGrade: DetailedArtGradeRecord = {
      id: `grade_${id}`,
      studentId: id,
      classId,
      sectionId,
      academicYear: profile.academicYear,
      oralM1: null,
      rawExamM1: null,
      examM1: null,
      avgM1: null,
      oralM2: null,
      rawExamM2: null,
      examM2: null,
      avgM2: null,
      sem1Pursuit: null,
      midYearExam: null,
      oralM3: null,
      rawExamM3: null,
      examM3: null,
      avgM3: null,
      oralM4: null,
      rawExamM4: null,
      examM4: null,
      avgM4: null,
      sem2Pursuit: null,
      annualPursuit: null,
      finalExam: null,
      finalGrade: null,
      resultStatus: 'غير مكتمل',
      notes: '',
      isProvisional: true,
      updatedAt: now,
    };

    setGrades((prev) => ({
      ...prev,
      [id]: emptyGrade,
    }));

    return id;
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    const now = new Date().toISOString();
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates, updatedAt: now } : s))
    );
  };

  const archiveStudent = (id: string) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, archived: !s.archived } : s))
    );
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
    setGrades((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setAttendance((prev) => prev.filter((a) => a.studentId !== id));
    setCompliances((prev) => {
      const next = { ...prev };
      delete next[`${id}_m1`];
      delete next[`${id}_m2`];
      delete next[`${id}_m3`];
      delete next[`${id}_m4`];
      return next;
    });
    setGiftedStudents((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  const importStudentsCSV = (
    csvText: string,
    classId: string,
    sectionId: string
  ): { added: number; duplicates: number } => {
    const lines = csvText
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    let added = 0;
    let duplicates = 0;

    const existingNames = new Set(
      students.filter((s) => s.classId === classId && s.sectionId === sectionId).map((s) => s.fullName)
    );

    const newStudents: Student[] = [];
    const newGrades: Record<string, DetailedArtGradeRecord> = {};
    const now = new Date().toISOString();

    lines.forEach((line) => {
      const cleanName = line.replace(/["',]/g, '').trim();
      if (!cleanName || cleanName.includes('الاسم') || cleanName.toLowerCase().includes('name')) return;

      if (existingNames.has(cleanName)) {
        duplicates++;
      } else {
        existingNames.add(cleanName);
        const stdId = `std_${Date.now()}_${added}`;
        const stdNumber = `${profile.academicYear.slice(0, 4)}${String(students.length + added + 1).padStart(3, '0')}`;

        newStudents.push({
          id: stdId,
          studentNumber: stdNumber,
          fullName: cleanName,
          classId,
          sectionId,
          status: 'مستمر',
          archived: false,
          createdAt: now,
          updatedAt: now,
        });

        newGrades[stdId] = {
          id: `grade_${stdId}`,
          studentId: stdId,
          classId,
          sectionId,
          academicYear: profile.academicYear,
          oralM1: null,
          rawExamM1: null,
          examM1: null,
          avgM1: null,
          oralM2: null,
          rawExamM2: null,
          examM2: null,
          avgM2: null,
          sem1Pursuit: null,
          midYearExam: null,
          oralM3: null,
          rawExamM3: null,
          examM3: null,
          avgM3: null,
          oralM4: null,
          rawExamM4: null,
          examM4: null,
          avgM4: null,
          sem2Pursuit: null,
          annualPursuit: null,
          finalExam: null,
          finalGrade: null,
          resultStatus: 'غير مكتمل',
          notes: '',
          isProvisional: true,
          updatedAt: now,
        };

        added++;
      }
    });

    if (newStudents.length > 0) {
      setStudents((prev) => [...prev, ...newStudents]);
      setGrades((prev) => ({ ...prev, ...newGrades }));
    }

    return { added, duplicates };
  };

  // Grade operations
  const getStudentGrade = (studentId: string): DetailedArtGradeRecord => {
    if (grades[studentId]) return grades[studentId];
    const std = students.find((s) => s.id === studentId);
    return {
      id: `grade_${studentId}`,
      studentId,
      classId: std?.classId || '',
      sectionId: std?.sectionId || '',
      academicYear: profile.academicYear,
      oralM1: null,
      rawExamM1: null,
      examM1: null,
      avgM1: null,
      oralM2: null,
      rawExamM2: null,
      examM2: null,
      avgM2: null,
      sem1Pursuit: null,
      midYearExam: null,
      oralM3: null,
      rawExamM3: null,
      examM3: null,
      avgM3: null,
      oralM4: null,
      rawExamM4: null,
      examM4: null,
      avgM4: null,
      sem2Pursuit: null,
      annualPursuit: null,
      finalExam: null,
      finalGrade: null,
      resultStatus: 'غير مكتمل',
      notes: '',
      isProvisional: true,
      updatedAt: new Date().toISOString(),
    };
  };

  const updateGradeField = (
    studentId: string,
    field: keyof DetailedArtGradeRecord,
    value: any
  ) => {
    const current = getStudentGrade(studentId);
    let updatedRaw: DetailedArtGradeRecord = {
      ...current,
      [field]: value,
    };

    // If teacher edited examM1, rawExamM1 is set to this value as baseline
    if (field === 'examM1') {
      updatedRaw.rawExamM1 = value;
    } else if (field === 'examM2') {
      updatedRaw.rawExamM2 = value;
    } else if (field === 'examM3') {
      updatedRaw.rawExamM3 = value;
    } else if (field === 'examM4') {
      updatedRaw.rawExamM4 = value;
    }

    // Apply any active monthly non-compliance deductions
    const finalRecord = applyDeductionsToRecord(updatedRaw, compliances, gradingConfig);

    setGrades((prev) => ({
      ...prev,
      [studentId]: finalRecord,
    }));
  };

  const batchSaveGrades = (updatedGrades: DetailedArtGradeRecord[]) => {
    setGrades((prev) => {
      const next = { ...prev };
      updatedGrades.forEach((g) => {
        next[g.studentId] = applyDeductionsToRecord(g, compliances, gradingConfig);
      });
      return next;
    });
  };

  // Attendance operations
  const saveDayAttendance = (
    classId: string,
    sectionId: string,
    date: string,
    records: { studentId: string; status: AttendanceStatus; reason?: string; notes?: string }[]
  ) => {
    const now = new Date().toISOString();
    setAttendance((prev) => {
      const studentIds = new Set(records.map((r) => r.studentId));
      const filtered = prev.filter(
        (a) => !(a.date === date && studentIds.has(a.studentId))
      );

      const newEntries: AttendanceRecord[] = records.map((r) => ({
        id: `att_${r.studentId}_${date}`,
        studentId: r.studentId,
        classId,
        sectionId,
        date,
        status: r.status,
        reason: r.reason || '',
        notes: r.notes || '',
        updatedAt: now,
      }));

      return [...filtered, ...newEntries];
    });
  };

  const getAttendanceForDate = (
    classId: string,
    sectionId: string,
    date: string
  ): Record<string, AttendanceRecord> => {
    const map: Record<string, AttendanceRecord> = {};
    attendance
      .filter((a) => a.classId === classId && a.sectionId === sectionId && a.date === date)
      .forEach((a) => {
        map[a.studentId] = a;
      });
    return map;
  };

  const getStudentAttendanceStats = (studentId: string) => {
    let totalAbsences = 0;
    let excused = 0;
    let late = 0;
    let present = 0;

    attendance
      .filter((a) => a.studentId === studentId)
      .forEach((a) => {
        if (a.status === 'غائب') totalAbsences++;
        if (a.status === 'مجاز') excused++;
        if (a.status === 'متأخر') late++;
        if (a.status === 'حاضر') present++;
      });

    return { totalAbsences, excused, late, present };
  };

  // ================= 1. NON-COMPLIANCE METHODS =================
  const getStudentMonthlyCompliance = (
    studentId: string,
    monthIndex: 1 | 2 | 3 | 4
  ): StudentMonthlyCompliance => {
    const key = `${studentId}_m${monthIndex}`;
    if (compliances[key]) return compliances[key];
    return createDefaultMonthlyCompliance(studentId, monthIndex);
  };

  const getAllStudentCompliances = (studentId: string): StudentMonthlyCompliance[] => {
    return [
      getStudentMonthlyCompliance(studentId, 1),
      getStudentMonthlyCompliance(studentId, 2),
      getStudentMonthlyCompliance(studentId, 3),
      getStudentMonthlyCompliance(studentId, 4),
    ];
  };

  const toggleNonComplianceCheck = (
    studentId: string,
    monthIndex: 1 | 2 | 3 | 4,
    checkIndex: 1 | 2 | 3 | 4,
    isNonCompliant?: boolean,
    reason?: string,
    date?: string
  ) => {
    const key = `${studentId}_m${monthIndex}`;
    const current = getStudentMonthlyCompliance(studentId, monthIndex);

    const updatedChecks = current.checks.map((chk) => {
      if (chk.checkIndex === checkIndex) {
        const nextVal = isNonCompliant !== undefined ? isNonCompliant : !chk.isNonCompliant;
        return {
          ...chk,
          isNonCompliant: nextVal,
          reason: reason !== undefined ? reason : chk.reason,
          date: date || chk.date || getTodayDateString(),
        };
      }
      return chk;
    }) as [NonComplianceCheck, NonComplianceCheck, NonComplianceCheck, NonComplianceCheck];

    // Calculate total deduction (5 marks per infraction, max 20)
    const infractionsCount = updatedChecks.filter((c) => c.isNonCompliant).length;
    const totalDeduction = Math.min(20, infractionsCount * 5);

    const updatedCompliance: StudentMonthlyCompliance = {
      ...current,
      checks: updatedChecks,
      totalDeduction,
      updatedAt: new Date().toISOString(),
    };

    const nextCompliances = {
      ...compliances,
      [key]: updatedCompliance,
    };

    setCompliances(nextCompliances);

    // Automatically recalculate the student's grade with the updated deductions!
    const currentGrade = getStudentGrade(studentId);
    const updatedGrade = applyDeductionsToRecord(currentGrade, nextCompliances, gradingConfig);

    setGrades((prev) => ({
      ...prev,
      [studentId]: updatedGrade,
    }));
  };

  // ================= 5. GIFTED STUDENTS METHODS =================
  const addGiftedStudent = (data: {
    studentId: string;
    talentDomain: string;
    discoveryDate: string;
    teacherNotes?: string;
    participations?: string;
  }) => {
    const now = new Date().toISOString();
    const entry: GiftedStudent = {
      id: data.studentId,
      studentId: data.studentId,
      talentDomain: data.talentDomain,
      discoveryDate: data.discoveryDate || getTodayDateString(),
      teacherNotes: data.teacherNotes || '',
      participations: data.participations || '',
      createdAt: now,
      updatedAt: now,
    };

    setGiftedStudents((prev) => ({
      ...prev,
      [data.studentId]: entry,
    }));
  };

  const updateGiftedStudent = (studentId: string, updates: Partial<GiftedStudent>) => {
    const now = new Date().toISOString();
    setGiftedStudents((prev) => {
      const cur = prev[studentId];
      if (!cur) return prev;
      return {
        ...prev,
        [studentId]: {
          ...cur,
          ...updates,
          updatedAt: now,
        },
      };
    });
  };

  const removeGiftedStudent = (studentId: string) => {
    setGiftedStudents((prev) => {
      const next = { ...prev };
      delete next[studentId];
      return next;
    });
  };

  const isStudentGifted = (studentId: string): boolean => {
    return Boolean(giftedStudents[studentId]);
  };

  // Full Backup JSON
  const exportFullBackupJSON = (): string => {
    const backup = {
      version: '3.0.0',
      exportedAt: new Date().toISOString(),
      profile,
      gradingConfig,
      classes,
      sections,
      students,
      grades,
      attendance,
      compliances,
      giftedStudents,
    };
    return JSON.stringify(backup, null, 2);
  };

  const importFullBackupJSON = (jsonText: string): { success: boolean; message: string } => {
    try {
      const data = JSON.parse(jsonText);
      if (!data.classes || !data.students) {
        return { success: false, message: 'الملف غير صالح أو لا يحتوي على بنية البيانات المطلوبة.' };
      }

      if (data.profile) setProfileState(data.profile);
      if (data.gradingConfig) setGradingConfigState(data.gradingConfig);
      setClasses(data.classes || []);
      setSections(data.sections || []);
      setStudents(data.students || []);
      setGrades(data.grades || {});
      setAttendance(data.attendance || []);
      setCompliances(data.compliances || {});
      setGiftedStudents(data.giftedStudents || {});

      return { success: true, message: 'تمت استعادة البيانات بنجاح.' };
    } catch (e) {
      return { success: false, message: 'فشل تحليل ملف JSON. يرجى التحقق من صحة الملف.' };
    }
  };

  const resetAppToDefaults = () => {
    setProfileState(DEFAULT_PROFILE);
    setGradingConfigState(DEFAULT_CONFIG);
    setClasses([]);
    setSections([]);
    setStudents([]);
    setGrades({});
    setAttendance([]);
    setCompliances({});
    setGiftedStudents({});
    setSelectedClassId('');
    setSelectedSectionId('');
    localStorage.clear();
  };

  // Seed realistic demonstration classes for Teacher Ali Al-Hunaidi (ثانوية الديوانية للمتميزين)
  const seedDemoTeacherData = () => {
    const now = new Date().toISOString();
    const c1Id = 'cls_demo_1';
    const c2Id = 'cls_demo_2';

    const demoClasses: ClassGrade[] = [
      { id: c1Id, name: 'الأول المتوسط', academicYear: '2026–2027', archived: false, createdAt: now, updatedAt: now },
      { id: c2Id, name: 'الثاني المتوسط', academicYear: '2026–2027', archived: false, createdAt: now, updatedAt: now },
    ];

    const s1Id = 'sec_demo_1';
    const s2Id = 'sec_demo_2';
    const demoSections: Section[] = [
      { id: s1Id, classId: c1Id, name: 'أ', archived: false, createdAt: now, updatedAt: now },
      { id: s2Id, classId: c1Id, name: 'ب', archived: false, createdAt: now, updatedAt: now },
    ];

    const demoStudentNames = [
      'حيدر كرار جاسم الجبوري',
      'محمد باقر حيدر الخفاجي',
      'حسين عمار راضي الشمري',
      'علي سيف الدين الموسوي',
      'يوسف ثامر صباح الزبيدي',
      'أحمد ميثم خضير البديري',
    ];

    const demoStudents: Student[] = demoStudentNames.map((name, i) => ({
      id: `std_demo_${i + 1}`,
      studentNumber: `202600${i + 1}`,
      fullName: name,
      classId: c1Id,
      sectionId: s1Id,
      status: 'مستمر',
      archived: false,
      createdAt: now,
      updatedAt: now,
    }));

    // Demo Compliances
    const demoCompliances: Record<string, StudentMonthlyCompliance> = {};
    // Student 3 has 1 infraction (Yellow)
    demoCompliances[`std_demo_3_m1`] = {
      id: `std_demo_3_m1`,
      studentId: 'std_demo_3',
      monthIndex: 1,
      checks: [
        { checkIndex: 1, isNonCompliant: true, reason: 'عدم إحضار كراس الرسم وأدوات التلوين', date: '2026-10-05' },
        { checkIndex: 2, isNonCompliant: false },
        { checkIndex: 3, isNonCompliant: false },
        { checkIndex: 4, isNonCompliant: false },
      ],
      totalDeduction: 5,
      notes: '',
      updatedAt: now,
    };

    // Student 5 has 2 infractions (Orange)
    demoCompliances[`std_demo_5_m1`] = {
      id: `std_demo_5_m1`,
      studentId: 'std_demo_5',
      monthIndex: 1,
      checks: [
        { checkIndex: 1, isNonCompliant: true, reason: 'عدم إحضار كراس الرسم', date: '2026-10-05' },
        { checkIndex: 2, isNonCompliant: true, reason: 'التأخر في تسليم اللوحة الفنية', date: '2026-10-12' },
        { checkIndex: 3, isNonCompliant: false },
        { checkIndex: 4, isNonCompliant: false },
      ],
      totalDeduction: 10,
      notes: '',
      updatedAt: now,
    };

    // Student 6 has 3 infractions (Red)
    demoCompliances[`std_demo_6_m1`] = {
      id: `std_demo_6_m1`,
      studentId: 'std_demo_6',
      monthIndex: 1,
      checks: [
        { checkIndex: 1, isNonCompliant: true, reason: 'عدم إحضار الأدوات الفنية', date: '2026-10-05' },
        { checkIndex: 2, isNonCompliant: true, reason: 'إهمال نظافة المرسم', date: '2026-10-12' },
        { checkIndex: 3, isNonCompliant: true, reason: 'مخالفة تعليمات الحصة الفنية', date: '2026-10-19' },
        { checkIndex: 4, isNonCompliant: false },
      ],
      totalDeduction: 15,
      notes: '',
      updatedAt: now,
    };

    const demoGrades: Record<string, DetailedArtGradeRecord> = {};
    demoStudents.forEach((std, i) => {
      const oral1 = 45 + (i * 1);
      const rawExam1 = 44 + (i * 1);
      const oral2 = 46 + (i * 1);
      const rawExam2 = 44 + (i * 1);
      const mid = 90 + (i * 1);

      const rec: DetailedArtGradeRecord = {
        id: `grade_${std.id}`,
        studentId: std.id,
        classId: c1Id,
        sectionId: s1Id,
        academicYear: '2026–2027',
        oralM1: oral1,
        rawExamM1: rawExam1,
        examM1: rawExam1,
        avgM1: null,
        oralM2: oral2,
        rawExamM2: rawExam2,
        examM2: rawExam2,
        avgM2: null,
        sem1Pursuit: null,
        midYearExam: mid,
        oralM3: null,
        rawExamM3: null,
        examM3: null,
        avgM3: null,
        oralM4: null,
        rawExamM4: null,
        examM4: null,
        avgM4: null,
        sem2Pursuit: null,
        annualPursuit: null,
        finalExam: null,
        finalGrade: null,
        resultStatus: 'غير مكتمل',
        notes: i === 0 ? 'متميز في رسم الطبيعة الصامتة والتظليل' : '',
        isProvisional: true,
        updatedAt: now,
      };

      demoGrades[std.id] = applyDeductionsToRecord(rec, demoCompliances, DEFAULT_CONFIG);
    });

    // Demo Gifted Students (Students 1 and 2)
    const demoGifted: Record<string, GiftedStudent> = {
      std_demo_1: {
        id: 'std_demo_1',
        studentId: 'std_demo_1',
        talentDomain: 'الرسم',
        discoveryDate: '2026-10-01',
        teacherNotes: 'مهارة استثنائية في الرسم بالألوان المائية والتظليل بالفحم',
        participations: 'المعرض السنوي لتربية الديوانية - المركز الأول',
        createdAt: now,
        updatedAt: now,
      },
      std_demo_2: {
        id: 'std_demo_2',
        studentId: 'std_demo_2',
        talentDomain: 'الخط العربي',
        discoveryDate: '2026-10-03',
        teacherNotes: 'إتقان خطي الرقعة والديواني بحرفية لافتة',
        participations: 'مسابقة الخط والزخرفة الإسلامية',
        createdAt: now,
        updatedAt: now,
      },
    };

    setClasses(demoClasses);
    setSections(demoSections);
    setStudents(demoStudents);
    setCompliances(demoCompliances);
    setGrades(demoGrades);
    setGiftedStudents(demoGifted);
    setSelectedClassId(c1Id);
    setSelectedSectionId(s1Id);
  };

  return (
    <TeacherAppContext.Provider
      value={{
        profile,
        setProfile,
        updateProfile,

        gradingConfig,
        setGradingConfig,
        updateGradingConfig,

        classes,
        addClass,
        updateClass,
        archiveClass,
        deleteClass,

        sections,
        addSection,
        updateSection,
        archiveSection,
        deleteSection,

        students,
        addStudent,
        updateStudent,
        archiveStudent,
        deleteStudent,
        importStudentsCSV,

        grades,
        updateGradeField,
        batchSaveGrades,
        getStudentGrade,

        attendance,
        saveDayAttendance,
        getAttendanceForDate,
        getStudentAttendanceStats,

        compliances,
        toggleNonComplianceCheck,
        getStudentMonthlyCompliance,
        getAllStudentCompliances,

        giftedStudents,
        addGiftedStudent,
        updateGiftedStudent,
        removeGiftedStudent,
        isStudentGifted,

        activeScreen,
        setActiveScreen,
        selectedClassId,
        setSelectedClassId,
        selectedSectionId,
        setSelectedSectionId,
        selectedDate,
        setSelectedDate,

        exportFullBackupJSON,
        importFullBackupJSON,
        resetAppToDefaults,
        seedDemoTeacherData,
      }}
    >
      {children}
    </TeacherAppContext.Provider>
  );
};

export const useTeacherApp = () => {
  const context = useContext(TeacherAppContext);
  if (!context) {
    throw new Error('useTeacherApp must be used within a TeacherAppProvider');
  }
  return context;
};
