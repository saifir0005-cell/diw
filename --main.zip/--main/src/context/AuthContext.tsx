import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleProvider, testConnection } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  effectiveTeacherId: string;
  signInWithGoogle: () => Promise<void>;
  signOutTeacher: () => Promise<void>;
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_TEACHER_KEY = 'iraqi_school_teacher_id';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [localTeacherId, setLocalTeacherId] = useState<string>(() => {
    let stored = localStorage.getItem(LOCAL_TEACHER_KEY);
    if (!stored) {
      stored = `teacher_${Math.random().toString(36).substring(2, 9)}`;
      localStorage.setItem(LOCAL_TEACHER_KEY, stored);
    }
    return stored;
  });

  useEffect(() => {
    // Validate connection to Firestore as required by Skill
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setIsDemoMode(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      setLoading(true);
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error('Google Sign In failed:', err);
      // If popup was blocked or failed, allow fallback to guest teacher mode
      setIsDemoMode(true);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signOutTeacher = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setIsDemoMode(false);
    } catch (err) {
      console.error('Sign Out failed:', err);
    }
  };

  const effectiveTeacherId = user ? user.uid : localTeacherId;

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        effectiveTeacherId,
        signInWithGoogle,
        signOutTeacher,
        isDemoMode,
        setIsDemoMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
