import React from 'react';
import { TeacherAppProvider, useTeacherApp } from './context/TeacherAppContext';
import { AndroidTopBar } from './components/AndroidTopBar';
import { AndroidBottomNav } from './components/AndroidBottomNav';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { ClassesSectionsScreen } from './components/screens/ClassesSectionsScreen';
import { StudentRegisterScreen } from './components/screens/StudentRegisterScreen';
import { GradebookScreen } from './components/screens/GradebookScreen';
import { FinalReportsScreen } from './components/screens/FinalReportsScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { AndroidCodeScreen } from './components/screens/AndroidCodeScreen';
import { NonComplianceScreen } from './components/screens/NonComplianceScreen';
import { GiftedStudentsScreen } from './components/screens/GiftedStudentsScreen';
import { StatisticsScreen } from './components/screens/StatisticsScreen';

const MainScreenRouter: React.FC = () => {
  const { activeScreen } = useTeacherApp();

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col font-['Cairo',sans-serif]" dir="rtl">
      {/* Top Application Bar */}
      <AndroidTopBar />

      {/* Main Viewport */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full">
        {activeScreen === 'dashboard' && <DashboardScreen />}
        {activeScreen === 'classes_sections' && <ClassesSectionsScreen />}
        {activeScreen === 'student_register' && <StudentRegisterScreen />}
        {activeScreen === 'gradebook_attendance' && <GradebookScreen />}
        {activeScreen === 'non_compliance' && <NonComplianceScreen />}
        {activeScreen === 'gifted_students' && <GiftedStudentsScreen />}
        {activeScreen === 'statistics' && <StatisticsScreen />}
        {activeScreen === 'final_reports' && <FinalReportsScreen />}
        {activeScreen === 'settings' && <SettingsScreen />}
        {activeScreen === 'android_code' && <AndroidCodeScreen />}
      </main>

      {/* Android Bottom Navigation */}
      <AndroidBottomNav />
    </div>
  );
};

export default function App() {
  return (
    <TeacherAppProvider>
      <MainScreenRouter />
    </TeacherAppProvider>
  );
}
