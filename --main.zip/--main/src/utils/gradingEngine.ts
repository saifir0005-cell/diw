import {
  DetailedArtGradeRecord,
  GradingConfig,
  ResultStatus,
  StudentMonthlyCompliance,
  CommitmentInfo,
  CommitmentLevel,
  AchievementLevel,
} from '../types';

export interface CalculationDetails {
  fieldName: string;
  formula: string;
  inputs: { name: string; value: number | null }[];
  result: number | null;
  ruleSet: string;
  isProvisional: boolean;
  notes: string;
  deductionApplied?: number;
  rawScore?: number | null;
}

export function roundScore(value: number, rule: 'standard' | 'floor' | 'ceil' = 'standard'): number {
  if (rule === 'floor') return Math.floor(value);
  if (rule === 'ceil') return Math.ceil(value);
  return Math.round(value);
}

/**
 * Calculates Monthly Average: (Oral + Exam) / 2
 * IMPORTANT: If either is null, returns null unless configured otherwise.
 */
export function calculateMonthlyAverage(
  oral: number | null,
  exam: number | null,
  config: GradingConfig
): number | null {
  if (oral === null || exam === null) {
    if (config.treatBlankAsZero) {
      const o = oral ?? 0;
      const e = exam ?? 0;
      return roundScore((o + e) / 2, config.roundingRule);
    }
    return null;
  }
  return roundScore((oral + exam) / 2, config.roundingRule);
}

/**
 * Calculates Semester Pursuit: (Month 1 Avg + Month 2 Avg) / 2
 */
export function calculateSemesterPursuit(
  m1Avg: number | null,
  m2Avg: number | null,
  config: GradingConfig
): number | null {
  if (m1Avg === null || m2Avg === null) {
    return null;
  }
  return roundScore((m1Avg + m2Avg) / 2, config.roundingRule);
}

/**
 * Calculates Annual Pursuit for non-final intermediate classes:
 * (First-Semester Pursuit + Second-Semester Pursuit + Midyear Examination) / 3
 */
export function calculateAnnualPursuit(
  sem1: number | null,
  sem2: number | null,
  midYear: number | null,
  config: GradingConfig
): { value: number | null; isProvisional: boolean } {
  if (sem1 !== null && sem2 !== null && midYear !== null) {
    const raw = (sem1 + sem2 + midYear) / 3;
    return {
      value: roundScore(raw, config.roundingRule),
      isProvisional: false,
    };
  }

  return {
    value: null,
    isProvisional: true,
  };
}

/**
 * Calculates Final Grade:
 * (Annual Pursuit + Final Examination) / 2
 */
export function calculateFinalGrade(
  annualPursuit: number | null,
  finalExam: number | null,
  config: GradingConfig
): { value: number | null; isProvisional: boolean; status: ResultStatus } {
  if (annualPursuit === null || finalExam === null) {
    return {
      value: null,
      isProvisional: true,
      status: 'غير مكتمل',
    };
  }

  const raw = (annualPursuit + finalExam) / 2;
  const grade = roundScore(raw, config.roundingRule);
  const status: ResultStatus = grade >= config.minPassingGrade ? 'ناجح' : 'مكمل';

  return {
    value: grade,
    isProvisional: false,
    status,
  };
}

/**
 * Applies non-compliance deductions to raw exam grades:
 * 5 marks per check, max 20 per month.
 * Does NOT touch oral, midyear, or final exam!
 * Preserves raw exam and never lets result fall below 0.
 */
export function applyDeductionsToRecord(
  record: DetailedArtGradeRecord,
  compliances: Record<string, StudentMonthlyCompliance>, // key `${studentId}_m${monthIndex}`
  config: GradingConfig
): DetailedArtGradeRecord {
  // Month 1
  const c1 = compliances[`${record.studentId}_m1`];
  const d1 = c1 ? Math.min(20, c1.totalDeduction) : 0;
  const raw1 = record.rawExamM1 !== undefined ? record.rawExamM1 : record.examM1;
  const exam1 = raw1 !== null ? Math.max(0, raw1 - d1) : null;

  // Month 2
  const c2 = compliances[`${record.studentId}_m2`];
  const d2 = c2 ? Math.min(20, c2.totalDeduction) : 0;
  const raw2 = record.rawExamM2 !== undefined ? record.rawExamM2 : record.examM2;
  const exam2 = raw2 !== null ? Math.max(0, raw2 - d2) : null;

  // Month 3 (Sem 2 M1)
  const c3 = compliances[`${record.studentId}_m3`];
  const d3 = c3 ? Math.min(20, c3.totalDeduction) : 0;
  const raw3 = record.rawExamM3 !== undefined ? record.rawExamM3 : record.examM3;
  const exam3 = raw3 !== null ? Math.max(0, raw3 - d3) : null;

  // Month 4 (Sem 2 M2)
  const c4 = compliances[`${record.studentId}_m4`];
  const d4 = c4 ? Math.min(20, c4.totalDeduction) : 0;
  const raw4 = record.rawExamM4 !== undefined ? record.rawExamM4 : record.examM4;
  const exam4 = raw4 !== null ? Math.max(0, raw4 - d4) : null;

  const baseRecord: DetailedArtGradeRecord = {
    ...record,
    rawExamM1: raw1,
    examM1: exam1,
    rawExamM2: raw2,
    examM2: exam2,
    rawExamM3: raw3,
    examM3: exam3,
    rawExamM4: raw4,
    examM4: exam4,
  };

  return recalculateStudentRecord(baseRecord, config);
}

/**
 * Recalculates all averages, pursuits, and final grades
 */
export function recalculateStudentRecord(
  record: DetailedArtGradeRecord,
  config: GradingConfig
): DetailedArtGradeRecord {
  // Month 1
  const avgM1 = calculateMonthlyAverage(record.oralM1, record.examM1, config);
  // Month 2
  const avgM2 = calculateMonthlyAverage(record.oralM2, record.examM2, config);
  // Sem 1 Pursuit
  const sem1Pursuit = calculateSemesterPursuit(avgM1, avgM2, config);

  // Month 3
  const avgM3 = calculateMonthlyAverage(record.oralM3, record.examM3, config);
  // Month 4
  const avgM4 = calculateMonthlyAverage(record.oralM4, record.examM4, config);
  // Sem 2 Pursuit
  const sem2Pursuit = calculateSemesterPursuit(avgM3, avgM4, config);

  // Annual Pursuit
  const annual = calculateAnnualPursuit(sem1Pursuit, sem2Pursuit, record.midYearExam, config);

  // Final Grade
  const final = calculateFinalGrade(annual.value, record.finalExam, config);

  const isProvisional =
    annual.isProvisional || final.isProvisional || record.finalExam === null;

  return {
    ...record,
    avgM1,
    avgM2,
    sem1Pursuit,
    avgM3,
    avgM4,
    sem2Pursuit,
    annualPursuit: annual.value,
    finalGrade: final.value,
    resultStatus: final.status,
    isProvisional,
    updatedAt: new Date().toISOString(),
  };
}

/**
 * 2. Color grading system for student commitment / discipline:
 * - Green: ملتزم وجيد (0 infractions)
 * - Yellow: تنبيه أولي (1 infraction / 5 marks)
 * - Orange: تكرار عدم الالتزام (2 infractions / 10 marks)
 * - Red: خصومات متكررة (3 infractions / 15 marks)
 * - Dark Red: حالة حرجة (4+ infractions / 20 marks)
 */
export function getCommitmentInfo(studentCompliances: StudentMonthlyCompliance[]): CommitmentInfo {
  let totalInfractions = 0;
  let totalDeduction = 0;

  studentCompliances.forEach((c) => {
    c.checks.forEach((chk) => {
      if (chk.isNonCompliant) {
        totalInfractions++;
      }
    });
    totalDeduction += c.totalDeduction;
  });

  if (totalInfractions === 0) {
    return {
      level: 'green',
      label: 'طالب ملتزم وجيد',
      colorClass: 'text-emerald-400',
      bgClass: 'bg-emerald-500/15',
      borderClass: 'border-emerald-500/30',
      totalInfractions,
      totalDeduction,
    };
  }

  if (totalInfractions === 1) {
    return {
      level: 'yellow',
      label: 'تنبيه أولي (خصم 5 درجات)',
      colorClass: 'text-amber-300',
      bgClass: 'bg-amber-500/15',
      borderClass: 'border-amber-500/30',
      totalInfractions,
      totalDeduction,
    };
  }

  if (totalInfractions === 2) {
    return {
      level: 'orange',
      label: 'تكرار عدم الالتزام (خصم 10 درجات)',
      colorClass: 'text-orange-400',
      bgClass: 'bg-orange-500/15',
      borderClass: 'border-orange-500/30',
      totalInfractions,
      totalDeduction,
    };
  }

  if (totalInfractions === 3) {
    return {
      level: 'red',
      label: 'خصومات متكررة (خصم 15 درجة)',
      colorClass: 'text-rose-400',
      bgClass: 'bg-rose-500/15',
      borderClass: 'border-rose-500/30',
      totalInfractions,
      totalDeduction,
    };
  }

  return {
    level: 'dark_red',
    label: 'حالة حرجة (خصم أقصى 20 درجة)',
    colorClass: 'text-rose-300 font-black',
    bgClass: 'bg-rose-950/80',
    borderClass: 'border-rose-700',
    totalInfractions,
    totalDeduction,
  };
}

/**
 * 4. Determines achievement level (مستوى التحصيل)
 */
export function getAchievementLevel(
  score: number | null,
  config: GradingConfig
): AchievementLevel {
  if (score === null) return 'غير مكتمل';
  const high = config.highAchievementThreshold ?? 85;
  const medium = config.mediumAchievementThreshold ?? 60;

  if (score >= high) return 'عالٍ';
  if (score >= medium) return 'متوسط';
  return 'منخفض';
}

/**
 * Step-by-step calculation breakdown for transparency & audit
 */
export function getDetailedCalculationBreakdown(
  record: DetailedArtGradeRecord,
  config: GradingConfig
): CalculationDetails[] {
  const steps: CalculationDetails[] = [];

  // Month 1
  steps.push({
    fieldName: 'معدل شهر تشرين الأول (شهر 1)',
    formula: '(الشفهي + التحريري الصافي بعد الخصم) ÷ 2',
    inputs: [
      { name: 'شفهي شهر 1', value: record.oralM1 },
      { name: 'تحريري شهر 1 الأصلي', value: record.rawExamM1 ?? record.examM1 },
      { name: 'تحريري شهر 1 بعد الخصم', value: record.examM1 },
    ],
    result: record.avgM1,
    ruleSet: 'النظام الوزاري المعتمد للمرحلة المتوسطة',
    isProvisional: record.avgM1 === null,
    notes: record.avgM1 === null ? 'بانتظار إدخال الدرجات كاملة' : 'محسوب ومكتمل',
    rawScore: record.rawExamM1,
  });

  // Month 2
  steps.push({
    fieldName: 'معدل شهر تشرين الثاني (شهر 2)',
    formula: '(الشفهي + التحريري الصافي بعد الخصم) ÷ 2',
    inputs: [
      { name: 'شفهي شهر 2', value: record.oralM2 },
      { name: 'تحريري شهر 2 الأصلي', value: record.rawExamM2 ?? record.examM2 },
      { name: 'تحريري شهر 2 بعد الخصم', value: record.examM2 },
    ],
    result: record.avgM2,
    ruleSet: 'النظام الوزاري المعتمد للمرحلة المتوسطة',
    isProvisional: record.avgM2 === null,
    notes: record.avgM2 === null ? 'بانتظار إدخال الدرجات كاملة' : 'محسوب ومكتمل',
    rawScore: record.rawExamM2,
  });

  // Sem 1 pursuit
  steps.push({
    fieldName: 'سعي الفصل الأول',
    formula: '(معدل شهر 1 + معدل شهر 2) ÷ 2',
    inputs: [
      { name: 'معدل شهر 1', value: record.avgM1 },
      { name: 'معدل شهر 2', value: record.avgM2 },
    ],
    result: record.sem1Pursuit,
    ruleSet: 'النظام الوزاري المعتمد للمرحلة المتوسطة',
    isProvisional: record.sem1Pursuit === null,
    notes: 'يمثل محصلة الفصل الدراسي الأول للتربية الفنية',
  });

  // Annual Pursuit
  steps.push({
    fieldName: 'السعي السنوي العام',
    formula: '(سعي الفصل الأول + سعي الفصل الثاني + امتحان نصف السنة) ÷ 3',
    inputs: [
      { name: 'سعي الفصل 1', value: record.sem1Pursuit },
      { name: 'امتحان نصف السنة', value: record.midYearExam },
      { name: 'سعي الفصل 2', value: record.sem2Pursuit },
    ],
    result: record.annualPursuit,
    ruleSet: `قواعد العام الدراسي ${config.academicYear} للتربية الفنية`,
    isProvisional: record.annualPursuit === null,
    notes:
      record.annualPursuit === null
        ? 'لا تظهر النتيجة كمعتمدة رسمياً إلا بعد اكتمال سعي الفصلين ونصف السنة'
        : 'معتمد رسمياً لدخول الامتحان النهائي',
  });

  // Final Grade
  steps.push({
    fieldName: 'الدرجة النهائية',
    formula: '(السعي السنوي + الامتحان النهائي) ÷ 2',
    inputs: [
      { name: 'السعي السنوي', value: record.annualPursuit },
      { name: 'الامتحان النهائي', value: record.finalExam },
    ],
    result: record.finalGrade,
    ruleSet: `قواعد العام الدراسي ${config.academicYear}`,
    isProvisional: record.finalGrade === null,
    notes:
      record.finalGrade !== null
        ? record.finalGrade >= config.minPassingGrade
          ? 'ناجح في مادة التربية الفنية'
          : 'مكمل (راسب بالدور الأول)'
        : 'قيد الإنجاز',
  });

  return steps;
}
