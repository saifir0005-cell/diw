/**
 * Iraqi Calendar & Date Utilities
 * Supports Gregorian with Iraqi/Levantine Arabic month names
 * and Islamic (Hijri) dates formatted in Arabic.
 */

// Iraqi/Levantine month names:
export const IRAQI_MONTH_NAMES = [
  'كانون الثاني', // 1
  'شباط',        // 2
  'آذار',        // 3
  'نيسان',       // 4
  'أيار',        // 5
  'حزيران',      // 6
  'تموز',        // 7
  'آب',          // 8
  'أيلول',       // 9
  'تشرين الأول',  // 10
  'تشرين الثاني', // 11
  'كانون الأول',  // 12
];

export const DAYS_ARABIC = [
  'الأحد',
  'الإثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
];

export function formatIraqiDate(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return '';
  const day = d.getDate();
  const month = IRAQI_MONTH_NAMES[d.getMonth()];
  const year = d.getFullYear();
  const dayName = DAYS_ARABIC[d.getDay()];
  return `${dayName}، ${day} ${month} ${year}`;
}

export function formatShortDate(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return '';
  const day = d.getDate();
  const month = IRAQI_MONTH_NAMES[d.getMonth()];
  const year = d.getFullYear();
  return `${day} ${month} ${year}`;
}

export function formatHijriDate(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return '';
  try {
    const formatter = new Intl.DateTimeFormat('ar-IQ-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return formatter.format(d) + ' هـ';
  } catch {
    // Fallback if islamic calendar not supported by environment
    return '';
  }
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getAcademicYearsList(): string[] {
  const currentYear = new Date().getFullYear();
  const list: string[] = [];
  for (let i = -2; i <= 2; i++) {
    const y = currentYear + i;
    list.push(`${y}-${y + 1}`);
  }
  return list;
}
