export interface TeacherProfile {
  teacherName: string;
  schoolName: string;
  subject: string;
  academicYear: string;
}

export interface ClassGrade {
  id: string;
  name: string; // e.g. الأول المتوسط, الثاني المتوسط, الثالث المتوسط
  academicYear: string;
  archived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Section {
  id: string;
  classId: string;
  name: string; // e.g. أ, ب, ج, د
  archived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type StudentStatus = 'مستمر' | 'منقول' | 'راسب' | 'تارك';

export interface Student {
  id: string;
  studentNumber: string; // e.g. 2026001
  fullName: string;
  classId: string;
  sectionId: string;
  notes?: string;
  status: StudentStatus;
  archived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type AttendanceStatus = 'حاضر' | 'غائب' | 'مجاز' | 'متأخر';

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  sectionId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  reason?: string;
  notes?: string;
  updatedAt: string;
}

export type ResultStatus = 'ناجح' | 'مكمل' | 'راسب' | 'غير مكتمل' | 'مؤجل';

export interface DetailedArtGradeRecord {
  id: string;
  studentId: string;
  classId: string;
  sectionId: string;
  academicYear: string;

  // FIRST SEMESTER:
  oralM1: number | null; // شفهي شهر 1
  rawExamM1?: number | null; // تحريري شهر 1 قبل الخصم
  examM1: number | null; // تحريري شهر 1 بعد الخصم (الصافي)
  avgM1: number | null; // معدل شهر 1 = (شفهي + تحريري) / 2
  oralM2: number | null; // شفهي شهر 2
  rawExamM2?: number | null; // تحريري شهر 2 قبل الخصم
  examM2: number | null; // تحريري شهر 2 بعد الخصم (الصافي)
  avgM2: number | null; // معدل شهر 2 = (شفهي + تحريري) / 2
  sem1Pursuit: number | null; // سعي الفصل الأول
  midYearExam: number | null; // امتحان نصف السنة

  // SECOND SEMESTER:
  oralM3: number | null; // شفهي شهر 1 (فصل 2)
  rawExamM3?: number | null; // تحريري شهر 1 (فصل 2) قبل الخصم
  examM3: number | null; // تحريري شهر 1 (فصل 2) بعد الخصم (الصافي)
  avgM3: number | null; // معدل شهر 1 (فصل 2)
  oralM4: number | null; // شفهي شهر 2 (فصل 2)
  rawExamM4?: number | null; // تحريري شهر 2 (فصل 2) قبل الخصم
  examM4: number | null; // تحريري شهر 2 (فصل 2) بعد الخصم (الصافي)
  avgM4: number | null; // معدل شهر 2 (فصل 2)
  sem2Pursuit: number | null; // سعي الفصل الثاني

  // ANNUAL RESULTS:
  annualPursuit: number | null; // السعي السنوي = (سعي 1 + سعي 2 + نصف السنة) / 3
  finalExam: number | null; // الامتحان النهائي
  finalGrade: number | null; // الدرجة النهائية = (السعي السنوي + النهائي) / 2
  resultStatus: ResultStatus;
  notes: string;
  isProvisional: boolean; // مؤقت أم معتمد نهائي
  updatedAt: string;
}

// 1. Non-Compliance (قسم غير الملتزم) Types
export interface NonComplianceCheck {
  checkIndex: 1 | 2 | 3 | 4; // المتابعة 1، 2، 3، 4
  isNonCompliant: boolean;
  date?: string;
  reason?: string;
}

export interface StudentMonthlyCompliance {
  id: string; // `${studentId}_m${monthIndex}`
  studentId: string;
  monthIndex: 1 | 2 | 3 | 4; // 1: شهر1 ف1, 2: شهر2 ف1, 3: شهر1 ف2, 4: شهر2 ف2
  checks: [NonComplianceCheck, NonComplianceCheck, NonComplianceCheck, NonComplianceCheck];
  totalDeduction: number; // 0, 5, 10, 15, or 20 max
  notes?: string;
  updatedAt: string;
}

export type CommitmentLevel = 'green' | 'yellow' | 'orange' | 'red' | 'dark_red';

export interface CommitmentInfo {
  level: CommitmentLevel;
  label: string;
  colorClass: string;
  bgClass: string;
  borderClass: string;
  totalInfractions: number;
  totalDeduction: number;
}

// 4. Achievement Level Types
export type AchievementLevel = 'عالٍ' | 'متوسط' | 'منخفض' | 'غير مكتمل';

// 5. Gifted Students (قسم الطلبة الموهوبين)
export type TalentDomain =
  | 'الرسم'
  | 'التلوين'
  | 'الخط العربي'
  | 'التصميم'
  | 'الأعمال اليدوية'
  | 'مجال مخصص';

export interface GiftedStudent {
  id: string; // Matches studentId
  studentId: string;
  talentDomain: string; // Standard or custom
  discoveryDate: string;
  teacherNotes: string;
  participations: string; // مشاركات ومعارض
  createdAt: string;
  updatedAt: string;
}

export interface GradingConfig {
  academicYear: string; // "2026–2027" or "2025–2026"
  minPassingGrade: number; // 50
  roundingRule: 'standard' | 'floor' | 'ceil';
  treatBlankAsZero: boolean; // default false
  formulaMode: 'verified_official' | 'teacher_configured';
  highAchievementThreshold: number; // default 85
  mediumAchievementThreshold: number; // default 60
}

export type MainNavScreen =
  | 'dashboard'
  | 'classes_sections'
  | 'student_register'
  | 'gradebook_attendance'
  | 'non_compliance'
  | 'statistics'
  | 'gifted_students'
  | 'final_reports'
  | 'settings'
  | 'android_code';
