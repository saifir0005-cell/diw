import React from 'react';
import {
  LayoutDashboard,
  Layers,
  Users,
  Palette,
  FileSpreadsheet,
  ShieldAlert,
  Award,
} from 'lucide-react';
import { useTeacherApp } from '../context/TeacherAppContext';
import { MainNavScreen } from '../types';

export const AndroidBottomNav: React.FC = () => {
  const { activeScreen, setActiveScreen, compliances } = useTeacherApp();

  const nonCompliantDeductionsCount = React.useMemo(() => {
    return Object.values(compliances).filter((c) => c.totalDeduction > 0).length;
  }, [compliances]);

  const navItems: { id: MainNavScreen; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'dashboard',
      label: 'الرئيسية',
      icon: <LayoutDashboard className="w-5 h-5" />,
    },
    {
      id: 'non_compliance',
      label: 'غير الملتزم',
      icon: <ShieldAlert className="w-5 h-5 text-rose-400" />,
      badge: nonCompliantDeductionsCount > 0 ? nonCompliantDeductionsCount : undefined,
    },
    {
      id: 'gradebook_attendance',
      label: 'الدرجات',
      icon: <Palette className="w-5 h-5" />,
    },
    {
      id: 'student_register',
      label: 'سجل الطلبة',
      icon: <Users className="w-5 h-5" />,
    },
    {
      id: 'gifted_students',
      label: 'الموهوبين',
      icon: <Award className="w-5 h-5 text-amber-400" />,
    },
    {
      id: 'final_reports',
      label: 'التقارير',
      icon: <FileSpreadsheet className="w-5 h-5" />,
    },
  ];

  return (
    <nav className="fixed bottom-0 right-0 left-0 z-40 bg-[#111827]/98 border-t border-slate-800 backdrop-blur-md shadow-2xl print:hidden">
      <div className="max-w-md md:max-w-xl mx-auto flex items-center justify-around px-2 py-1.5">
        {navItems.map((item) => {
          const isActive = activeScreen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveScreen(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-2xl transition-all cursor-pointer relative min-w-[62px] ${
                isActive
                  ? 'text-sky-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              <div
                className={`w-10 h-7 rounded-full flex items-center justify-center transition-all relative ${
                  isActive ? 'bg-sky-500/20 text-sky-400' : 'text-slate-400'
                }`}
              >
                {item.icon}
                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-black flex items-center justify-center shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-0.5 whitespace-nowrap tracking-tight">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
