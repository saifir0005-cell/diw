import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  Download,
  Terminal,
  FileCode,
  Layers,
  Sparkles,
} from 'lucide-react';

const KOTLIN_FILES = [
  {
    name: 'IraqiGradingEngine.kt',
    path: 'android/app/src/main/java/iq/teacher/schoolrecord/domain/engine/IraqiGradingEngine.kt',
    desc: 'محرك القواعد الوزارية لحساب المعدلات الشهرية، السعي الفصلي، والسعي السنوي',
    code: `package iq.teacher.schoolrecord.domain.engine

/**
 * Iraqi Art Education Intermediate School Grading Engine
 * Implements official ministerial formulas for 2026–2027 and 2025–2026.
 * Specifically for: الأستاذ علي الهنيدي - ثانوية الديوانية للمتميزين
 */
object IraqiGradingEngine {

    /**
     * Calculates Monthly Average: (Oral + Written Exam) / 2
     * Returns null if either component is missing to avoid penalizing student prematurely.
     */
    fun calculateMonthlyAverage(oral: Double?, exam: Double?): Double? {
        if (oral == null || exam == null) return null
        return (oral + exam) / 2.0
    }

    /**
     * Calculates Semester Pursuit: (Month 1 Average + Month 2 Average) / 2
     */
    fun calculateSemesterPursuit(month1Avg: Double?, month2Avg: Double?): Double? {
        if (month1Avg == null || month2Avg == null) return null
        return (month1Avg + month2Avg) / 2.0
    }

    /**
     * Calculates Annual Pursuit for non-final intermediate school classes (الصفين الأول والثاني المتوسط):
     * Annual Pursuit = (First-Semester Pursuit + Second-Semester Pursuit + Midyear Examination) / 3
     */
    fun calculateAnnualPursuit(
        sem1Pursuit: Double?,
        sem2Pursuit: Double?,
        midYearExam: Double?
    ): Double? {
        if (sem1Pursuit == null || sem2Pursuit == null || midYearExam == null) return null
        return (sem1Pursuit + sem2Pursuit + midYearExam) / 3.0
    }

    /**
     * Calculates Final Grade for applicable non-final subject examinations:
     * Final Grade = (Annual Pursuit + Final Examination) / 2
     */
    fun calculateFinalGrade(annualPursuit: Double?, finalExam: Double?): Double? {
        if (annualPursuit == null || finalExam == null) return null
        return (annualPursuit + finalExam) / 2.0
    }

    /**
     * Determines passing status (Min passing grade is 50 for Iraqi schools).
     */
    fun isPassing(grade: Double?, minPassingGrade: Double = 50.0): Boolean {
        if (grade == null) return false
        return grade >= minPassingGrade
    }
}`,
  },
  {
    name: 'AppDatabase.kt',
    path: 'android/app/src/main/java/iq/teacher/schoolrecord/data/local/AppDatabase.kt',
    desc: 'قاعدة بيانات Room المحلية والكيانات (Entities) والـ DAOs',
    code: `package iq.teacher.schoolrecord.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "classes")
data class ClassEntity(
    @PrimaryKey val id: String,
    val name: String,
    val academicYear: String,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sections",
    foreignKeys = [
        ForeignKey(
            entity = ClassEntity::class,
            parentColumns = ["id"],
            childColumns = ["classId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class SectionEntity(
    @PrimaryKey val id: String,
    val classId: String,
    val name: String,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "students",
    foreignKeys = [
        ForeignKey(
            entity = SectionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sectionId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class StudentEntity(
    @PrimaryKey val id: String,
    val studentNumber: String,
    val fullName: String,
    val classId: String,
    val sectionId: String,
    val notes: String = "",
    val status: String = "مستمر",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "art_grades")
data class DetailedArtGradeEntity(
    @PrimaryKey val studentId: String,
    val classId: String,
    val sectionId: String,
    val academicYear: String,
    val oralM1: Double? = null,
    val examM1: Double? = null,
    val avgM1: Double? = null,
    val oralM2: Double? = null,
    val examM2: Double? = null,
    val avgM2: Double? = null,
    val sem1Pursuit: Double? = null,
    val midYearExam: Double? = null,
    val oralM3: Double? = null,
    val examM3: Double? = null,
    val avgM3: Double? = null,
    val oralM4: Double? = null,
    val examM4: Double? = null,
    val avgM4: Double? = null,
    val sem2Pursuit: Double? = null,
    val annualPursuit: Double? = null,
    val finalExam: Double? = null,
    val finalGrade: Double? = null,
    val resultStatus: String = "غير مكتمل",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class AttendanceEntity(
    @PrimaryKey val id: String,
    val studentId: String,
    val classId: String,
    val sectionId: String,
    val date: String,
    val status: String,
    val reason: String = "",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface SchoolDao {
    @Query("SELECT * FROM classes WHERE isArchived = 0")
    fun getAllClasses(): Flow<List<ClassEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(classEntity: ClassEntity)

    @Query("SELECT * FROM sections WHERE classId = :classId AND isArchived = 0")
    fun getSectionsForClass(classId: String): Flow<List<SectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSection(sectionEntity: SectionEntity)

    @Query("SELECT * FROM students WHERE sectionId = :sectionId AND isArchived = 0")
    fun getStudentsForSection(sectionId: String): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>)

    @Query("SELECT * FROM art_grades WHERE studentId = :studentId")
    suspend fun getGradeForStudent(studentId: String): DetailedArtGradeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGrade(grade: DetailedArtGradeEntity)

    @Query("SELECT * FROM attendance WHERE classId = :classId AND sectionId = :sectionId AND date = :date")
    fun getAttendanceForDate(classId: String, sectionId: String, date: String): Flow<List<AttendanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(records: List<AttendanceEntity>)
}

@Database(
    entities = [
        ClassEntity::class,
        SectionEntity::class,
        StudentEntity::class,
        DetailedArtGradeEntity::class,
        AttendanceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao
}`,
  },
  {
    name: 'GradingFormulaTest.kt',
    path: 'android/app/src/test/java/iq/teacher/schoolrecord/GradingFormulaTest.kt',
    desc: 'اختبارات الوحدة (Unit Tests) لجميع معادلات واختبارات الدرجات',
    code: `package iq.teacher.schoolrecord

import iq.teacher.schoolrecord.domain.engine.IraqiGradingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GradingFormulaTest {

    @Test
    fun testMonthlyAverageCalculation() {
        val oral = 46.0
        val exam = 44.0
        val avg = IraqiGradingEngine.calculateMonthlyAverage(oral, exam)
        assertEquals(45.0, avg ?: 0.0, 0.001)
    }

    @Test
    fun testMissingGradeReturnsNullNeverZero() {
        // Critical requirement: Never convert a blank grade into zero!
        val oral = 48.0
        val exam: Double? = null
        val avg = IraqiGradingEngine.calculateMonthlyAverage(oral, exam)
        assertNull("Missing grade must return null, not 0.0", avg)
    }

    @Test
    fun testSemesterPursuitCalculation() {
        val m1 = 45.0
        val m2 = 47.0
        val pursuit = IraqiGradingEngine.calculateSemesterPursuit(m1, m2)
        assertEquals(46.0, pursuit ?: 0.0, 0.001)
    }

    @Test
    fun testAnnualPursuitCalculation() {
        val sem1 = 45.0
        val sem2 = 45.0
        val midYear = 90.0
        val annual = IraqiGradingEngine.calculateAnnualPursuit(sem1, sem2, midYear)
        assertEquals(60.0, annual ?: 0.0, 0.001)
    }

    @Test
    fun testFinalGradeAndPassingStatus() {
        val annualPursuit = 60.0
        val finalExam = 70.0
        val finalGrade = IraqiGradingEngine.calculateFinalGrade(annualPursuit, finalExam)
        assertEquals(65.0, finalGrade ?: 0.0, 0.001)

        assertTrue(IraqiGradingEngine.isPassing(finalGrade, 50.0))
        assertFalse(IraqiGradingEngine.isPassing(49.0, 50.0))
    }
}`,
  },
  {
    name: 'app/build.gradle.kts',
    path: 'android/app/build.gradle.kts',
    desc: 'إعدادات بناء أندرويد والتبعيات (Jetpack Compose, Room, Kotlin)',
    code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "iq.teacher.schoolrecord"
    compileSdk = 35

    defaultConfig {
        applicationId = "iq.teacher.schoolrecord"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.material3)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    testImplementation(libs.junit)
}`,
  },
];

export const AndroidCodeScreen: React.FC = () => {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeFile = KOTLIN_FILES[activeFileIndex];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Code2 className="w-6 h-6 text-teal-400" />
            <span>مشروع Android Native (Kotlin & Jetpack Compose)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            ملفات الكود البرمجي لمشروع أندرويد ستوديو (Room Database, ViewModel, Material 3)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-teal-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
          </button>

          <button
            onClick={handleDownloadFile}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-lg shadow-teal-950/40 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل الملف</span>
          </button>
        </div>
      </div>

      {/* File Selector Tabs */}
      <div className="flex flex-wrap gap-2 p-1.5 bg-[#161F30] border border-slate-800 rounded-2xl">
        {KOTLIN_FILES.map((f, idx) => (
          <button
            key={f.name}
            onClick={() => setActiveFileIndex(idx)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeFileIndex === idx
                ? 'bg-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>{f.name}</span>
          </button>
        ))}
      </div>

      {/* Code Viewer Container */}
      <div className="rounded-3xl bg-[#0B0F17] border border-slate-800 shadow-2xl overflow-hidden font-mono text-xs">
        {/* File Header */}
        <div className="px-5 py-3 bg-[#111827] border-b border-slate-800 flex items-center justify-between text-slate-400">
          <span className="font-bold text-teal-400 text-xs">{activeFile.path}</span>
          <span className="text-[11px] text-slate-500 font-sans">{activeFile.desc}</span>
        </div>

        {/* Code Content */}
        <pre className="p-5 text-slate-200 overflow-x-auto leading-relaxed max-h-[500px] overflow-y-auto custom-scrollbar" dir="ltr">
          <code>{activeFile.code}</code>
        </pre>
      </div>
    </div>
  );
};
