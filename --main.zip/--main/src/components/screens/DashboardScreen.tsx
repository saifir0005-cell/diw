import React from 'react';
import {
  Layers,
  Users,
  Palette,
  FileSpreadsheet,
  CalendarCheck2,
  AlertCircle,
  ArrowLeft,
  Sparkles,
  School,
  Clock,
  BookOpen,
  ShieldAlert,
  Award,
  TrendingUp,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import { getTodayDateString, formatIraqiDate, formatHijriDate } from '../../utils/dateUtils';

export const DashboardScreen: React.FC = () => {
  const {
    profile,
    classes,
    sections,
    students,
    grades,
    attendance,
    compliances,
    giftedStudents,
    setActiveScreen,
    setSelectedDate,
  } = useTeacherApp();

  const todayStr = getTodayDateString();

  // Active (unarchived) entities
  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => !s.archived);
  const activeStudents = students.filter((s) => !s.archived && s.status === 'مستمر');

  // Today's absences
  const todayAbsencesCount = attendance.filter(
    (a) => a.date === todayStr && a.status === 'غائب'
  ).length;

  // Incomplete grades: students whose annualPursuit is null
  const incompleteGradesCount = activeStudents.filter((std) => {
    const g = grades[std.id];
    return !g || g.annualPursuit === null;
  }).length;

  // Non-compliant students count
  const nonCompliantRecords = Object.values(compliances).filter((c) => c.totalDeduction > 0);
  const nonCompliantStudentsSet = new Set(nonCompliantRecords.map((c) => c.studentId));
  const nonCompliantCount = nonCompliantStudentsSet.size;

  // Gifted students count
  const giftedCount = Object.keys(giftedStudents).length;

  const handleOpenTodayAttendance = () => {
    setSelectedDate(todayStr);
    setActiveScreen('gradebook_attendance');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-24">
      {/* Teacher Profile & School Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-br from-[#162235] via-[#111927] to-[#0D131F] border border-slate-800/80 p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-950/80 text-sky-300 text-xs font-bold border border-sky-800/60">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span>{profile.subject} • العام الدراسي {profile.academicYear}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
              {profile.teacherName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-medium flex items-center gap-1.5">
              <School className="w-4 h-4 text-teal-400 shrink-0" />
              <span>{profile.schoolName}</span>
            </p>
          </div>

          <div className="text-right sm:text-left text-xs text-slate-400 border-t sm:border-t-0 sm:border-r border-slate-800 pt-3 sm:pt-0 sm:pr-4 w-full sm:w-auto">
            <span className="text-slate-300 font-bold block">{formatIraqiDate(new Date())}</span>
            <span className="text-amber-400/90 text-[11px] block">{formatHijriDate(new Date())}</span>
          </div>
        </div>
      </div>

      {/* Prominent Quick Actions Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Enter Today's Attendance */}
        <button
          onClick={handleOpenTodayAttendance}
          className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-teal-600 via-teal-700 to-sky-700 hover:from-teal-500 hover:to-sky-600 text-white font-bold text-sm shadow-lg shadow-teal-950/40 transition-all cursor-pointer group border border-teal-500/30"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white backdrop-blur-xs">
              <CalendarCheck2 className="w-5 h-5 text-white" />
            </div>
            <div className="text-right">
              <span className="block font-black text-sm text-white">
                تسجيل غيابات وحضور اليوم
              </span>
              <span className="block text-[11px] text-teal-100/90 font-normal">
                رصد سريع لشعب وصفوف اليوم وتثبيت الغياب
              </span>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:-translate-x-1 transition-transform">
            <ArrowLeft className="w-4 h-4 text-white" />
          </div>
        </button>

        {/* Quick Action: Non-Compliance Registry */}
        <button
          onClick={() => setActiveScreen('non_compliance')}
          className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-rose-900/90 via-rose-800 to-rose-700 hover:from-rose-800 hover:to-rose-600 text-white font-bold text-sm shadow-lg shadow-rose-950/40 transition-all cursor-pointer group border border-rose-500/40"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white backdrop-blur-xs">
              <ShieldAlert className="w-5 h-5 text-white" />
            </div>
            <div className="text-right">
              <span className="block font-black text-sm text-white flex items-center gap-2">
                <span>قسم غير الملتزم والانضباط</span>
                {nonCompliantCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-white text-rose-900 text-[10px] font-black">
                    {nonCompliantCount} طالب
                  </span>
                )}
              </span>
              <span className="block text-[11px] text-rose-100/90 font-normal">
                متابعة 4 مرات شهرياً • خصم 5 درجات • نظام الألوان
              </span>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:-translate-x-1 transition-transform">
            <ArrowLeft className="w-4 h-4 text-white" />
          </div>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Students */}
        <div
          onClick={() => setActiveScreen('student_register')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-slate-800/90 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">الطلبة</span>
            <Users className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-white">{activeStudents.length}</div>
          <span className="text-[10px] text-sky-400/90 font-medium block mt-1">
            سجل الطلاب
          </span>
        </div>

        {/* Classes */}
        <div
          onClick={() => setActiveScreen('classes_sections')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-slate-800/90 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">الصفوف</span>
            <Layers className="w-4 h-4 text-teal-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-white">{activeClasses.length}</div>
          <span className="text-[10px] text-teal-400/90 font-medium block mt-1">
            مراحل دراسية
          </span>
        </div>

        {/* Non-Compliant Students */}
        <div
          onClick={() => setActiveScreen('non_compliance')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-rose-500/30 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-rose-400 mb-1.5">
            <span className="text-[11px] font-bold">غير الملتزم</span>
            <ShieldAlert className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-rose-400">{nonCompliantCount}</div>
          <span className="text-[10px] text-rose-300 font-medium block mt-1">
            لديهم تنبيهات/خصم
          </span>
        </div>

        {/* Gifted Students */}
        <div
          onClick={() => setActiveScreen('gifted_students')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-amber-500/30 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-amber-400 mb-1.5">
            <span className="text-[11px] font-bold">الموهوبين</span>
            <Award className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-amber-400">{giftedCount}</div>
          <span className="text-[10px] text-amber-300 font-medium block mt-1">
            مواهب مسجلة
          </span>
        </div>

        {/* Today's Recorded Absences */}
        <div
          onClick={() => setActiveScreen('gradebook_attendance')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-slate-800/90 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">غيابات اليوم</span>
            <Clock className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-rose-400">{todayAbsencesCount}</div>
          <span className="text-[10px] text-slate-400 font-medium block mt-1">
            {todayAbsencesCount === 0 ? 'لا غيابات' : 'طالب غائب'}
          </span>
        </div>

        {/* Incomplete Grade Records */}
        <div
          onClick={() => setActiveScreen('gradebook_attendance')}
          className="bg-[#161F30] hover:bg-[#1C283F] border border-slate-800/90 p-4 rounded-2xl cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">غير مكتملة</span>
            <AlertCircle className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-black text-amber-400">{incompleteGradesCount}</div>
          <span className="text-[10px] text-amber-400/80 font-medium block mt-1">
            بحاجة لرصد
          </span>
        </div>
      </div>

      {/* Main Feature Cards */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
          أقسام سجلي المدرسي
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {/* 1. Classes & Sections */}
          <div
            onClick={() => setActiveScreen('classes_sections')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-teal-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-400 flex items-center justify-center font-bold">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-teal-300 transition-colors">
                  1. الصفوف والشعب
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  إدارة المراحل والشعب الدراسية
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-teal-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 2. Student Register */}
          <div
            onClick={() => setActiveScreen('student_register')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-sky-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center font-bold">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-sky-300 transition-colors">
                  2. سجل الطلبة
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  الأسماء والأرقام التسلسلية والاستيراد
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-sky-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 3. Non-Compliance Section */}
          <div
            onClick={() => setActiveScreen('non_compliance')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-rose-900/60 hover:border-rose-500/60 transition-all cursor-pointer group flex items-center justify-between shadow-sm relative overflow-hidden"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center font-bold">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-rose-300 transition-colors flex items-center gap-1.5">
                  <span>3. قسم غير الملتزم</span>
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  متابعة 4 مرات شهرياً • نظام الألوان
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-rose-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 4. Grades & Attendance */}
          <div
            onClick={() => setActiveScreen('gradebook_attendance')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center font-bold">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-amber-300 transition-colors">
                  4. الدرجات والغيابات
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  سجل التربية الفنية والغياب اليومي
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-amber-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 5. Gifted Students */}
          <div
            onClick={() => setActiveScreen('gifted_students')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center font-bold">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-amber-300 transition-colors">
                  5. الطلبة الموهوبين
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  توثيق مواهب الرسم والخط والمعارض
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-amber-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 6. Statistics & Achievement Levels */}
          <div
            onClick={() => setActiveScreen('statistics')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-bold">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-indigo-300 transition-colors">
                  6. الإحصائيات ومستويات التحصيل
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  نسب التحصيل والنجاح ولوحة الشرف
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 group-hover:-translate-x-1 transition-all" />
          </div>

          {/* 7. Final Reports */}
          <div
            onClick={() => setActiveScreen('final_reports')}
            className="p-5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-800 hover:border-sky-500/40 transition-all cursor-pointer group flex items-center justify-between shadow-sm col-span-1 sm:col-span-2 lg:col-span-3"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-11 h-11 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center font-bold">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white group-hover:text-sky-300 transition-colors">
                  7. التقارير النهائية والكشوفات الرسمية
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  كشوفات درجات التربية الفنية الرسمية المعتمدة والطباعة الورقية والتصدير لـ CSV
                </p>
              </div>
            </div>
            <ArrowLeft className="w-4 h-4 text-slate-500 group-hover:text-sky-400 group-hover:-translate-x-1 transition-all" />
          </div>
        </div>
      </div>
    </div>
  );
};
