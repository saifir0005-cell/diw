import React, { useMemo } from 'react';
import {
  TrendingUp,
  Award,
  Users,
  ShieldAlert,
  Layers,
  Sparkles,
  Printer,
  Download,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BookOpen,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import {
  getAchievementLevel,
  getCommitmentInfo,
} from '../../utils/gradingEngine';
import { formatIraqiDate } from '../../utils/dateUtils';

export const StatisticsScreen: React.FC = () => {
  const {
    classes,
    sections,
    students,
    grades,
    compliances,
    getAllStudentCompliances,
    selectedClassId,
    setSelectedClassId,
    selectedSectionId,
    setSelectedSectionId,
    gradingConfig,
    profile,
  } = useTeacherApp();

  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);

  // Active students
  const targetStudents = useMemo(() => {
    return students.filter(
      (s) =>
        (!selectedClassId || s.classId === selectedClassId) &&
        (!selectedSectionId || s.sectionId === selectedSectionId) &&
        !s.archived &&
        s.status === 'مستمر'
    );
  }, [students, selectedClassId, selectedSectionId]);

  // Calculations
  const stats = useMemo(() => {
    const total = targetStudents.length;
    if (total === 0) {
      return {
        total: 0,
        high: 0,
        medium: 0,
        low: 0,
        incomplete: 0,
        passed: 0,
        failed: 0,
        green: 0,
        yellow: 0,
        orange: 0,
        red: 0,
        darkRed: 0,
        topStudents: [],
      };
    }

    let high = 0;
    let medium = 0;
    let low = 0;
    let incomplete = 0;
    let passed = 0;
    let failed = 0;

    let green = 0;
    let yellow = 0;
    let orange = 0;
    let red = 0;
    let darkRed = 0;

    const studentScores: { student: (typeof targetStudents)[0]; score: number; level: string }[] = [];

    targetStudents.forEach((std) => {
      const g = grades[std.id];
      const allComp = getAllStudentCompliances(std.id);
      const commit = getCommitmentInfo(allComp);

      // Commitment counts
      if (commit.level === 'green') green++;
      else if (commit.level === 'yellow') yellow++;
      else if (commit.level === 'orange') orange++;
      else if (commit.level === 'red') red++;
      else if (commit.level === 'dark_red') darkRed++;

      // Grade benchmark score: preferably annualPursuit or finalGrade or sem1Pursuit
      const effectiveScore = g?.finalGrade ?? g?.annualPursuit ?? g?.sem1Pursuit ?? null;
      const ach = getAchievementLevel(effectiveScore, gradingConfig);

      if (ach === 'عالٍ') high++;
      else if (ach === 'متوسط') medium++;
      else if (ach === 'منخفض') low++;
      else incomplete++;

      if (effectiveScore !== null) {
        if (effectiveScore >= gradingConfig.minPassingGrade) passed++;
        else failed++;

        studentScores.push({
          student: std,
          score: effectiveScore,
          level: ach,
        });
      }
    });

    studentScores.sort((a, b) => b.score - a.score);

    return {
      total,
      high,
      medium,
      low,
      incomplete,
      passed,
      failed,
      green,
      yellow,
      orange,
      red,
      darkRed,
      topStudents: studentScores.slice(0, 5),
    };
  }, [targetStudents, grades, getAllStudentCompliances, gradingConfig]);

  const selectedClass = classes.find((c) => c.id === selectedClassId);
  const selectedSection = sections.find((s) => s.id === selectedSectionId);

  const getPercent = (count: number) => {
    if (stats.total === 0) return 0;
    return Math.round((count / stats.total) * 100);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 text-indigo-300 text-xs font-bold border border-indigo-500/30 mb-2">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span>مؤشرات الأداء وتحليل المستويات</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>قسم الإحصائيات ومستويات التحصيل</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            رصد إحصائي فوري لتوزيع مستويات التحصيل (عالٍ، متوسط، منخفض) وحالات الالتزام ومعدلات النجاح.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="px-4 py-2 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
        >
          <Printer className="w-4 h-4 text-sky-400" />
          <span>طباعة تقرير الإحصاء</span>
        </button>
      </div>

      {/* Selectors Toolbar */}
      <div className="p-4 rounded-3xl bg-[#161F30] border border-slate-800 space-y-3 shadow-md">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Class */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الصف الدراسي</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                const firstSec = sections.find((s) => s.classId === e.target.value);
                if (firstSec) setSelectedSectionId(firstSec.id);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              <option value="">كافة الصفوف الدراسية</option>
              {activeClasses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشعبة</label>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              <option value="">كافة الشعب</option>
              {activeSections.map((sec) => (
                <option key={sec.id} value={sec.id}>
                  شعبة {sec.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>
            النطاق المختار: <b className="text-white">{selectedClass ? selectedClass.name : 'جميع الصفوف'}</b>
            {selectedSection ? ` • شعبة ${selectedSection.name}` : ''}
          </span>
          <span>
            إجمالي الطلبة الخاضعين للتحليل: <b className="text-sky-400">{stats.total} طالب</b>
          </span>
        </div>
      </div>

      {/* Grid: 2 Major Cards (Achievement Levels & Discipline Levels) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Achievement Levels Card */}
        <div className="p-6 rounded-3xl bg-[#161F30] border border-slate-800 space-y-5 shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center font-bold">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-white">مستويات التحصيل الأكاديمي</h3>
            </div>
            <span className="text-[10px] text-slate-400">
              حد الامتياز: ≥{gradingConfig.highAchievementThreshold} • حد المتوسط: ≥{gradingConfig.mediumAchievementThreshold}
            </span>
          </div>

          {/* Visual Bar Distribution */}
          <div className="space-y-4">
            {/* High (عالٍ) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-teal-400 font-bold flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-400" />
                  <span>مستوى عالٍ (ممتاز وجيد جداً)</span>
                </span>
                <span className="text-slate-300 font-mono font-bold">
                  {stats.high} طالب ({getPercent(stats.high)}%)
                </span>
              </div>
              <div className="h-2.5 w-full bg-[#0D131F] rounded-full overflow-hidden">
                <div
                  className="h-full bg-teal-400 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(stats.high)}%` }}
                />
              </div>
            </div>

            {/* Medium (متوسط) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-sky-400 font-bold flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
                  <span>مستوى متوسط (جيد ومقبول)</span>
                </span>
                <span className="text-slate-300 font-mono font-bold">
                  {stats.medium} طالب ({getPercent(stats.medium)}%)
                </span>
              </div>
              <div className="h-2.5 w-full bg-[#0D131F] rounded-full overflow-hidden">
                <div
                  className="h-full bg-sky-400 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(stats.medium)}%` }}
                />
              </div>
            </div>

            {/* Low (منخفض) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-rose-400 font-bold flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  <span>مستوى منخفض (دون حد النجاح 50)</span>
                </span>
                <span className="text-slate-300 font-mono font-bold">
                  {stats.low} طالب ({getPercent(stats.low)}%)
                </span>
              </div>
              <div className="h-2.5 w-full bg-[#0D131F] rounded-full overflow-hidden">
                <div
                  className="h-full bg-rose-400 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(stats.low)}%` }}
                />
              </div>
            </div>

            {/* Incomplete (غير مكتمل) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-bold flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
                  <span>غير مكتمل (بانتظار رصد الدرجات)</span>
                </span>
                <span className="text-slate-400 font-mono font-bold">
                  {stats.incomplete} طالب ({getPercent(stats.incomplete)}%)
                </span>
              </div>
              <div className="h-2.5 w-full bg-[#0D131F] rounded-full overflow-hidden">
                <div
                  className="h-full bg-slate-600 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(stats.incomplete)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Discipline & Commitment Breakdown */}
        <div className="p-6 rounded-3xl bg-[#161F30] border border-slate-800 space-y-5 shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center font-bold">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-white">إحصائيات نظام ألوان الالتزام والانضباط</h3>
            </div>
            <span className="text-[10px] text-slate-400">5 درجات/متابعة</span>
          </div>

          <div className="space-y-3">
            {/* Green */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[#0D131F] border border-emerald-500/20 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-xs shadow-emerald-500" />
                <span className="font-bold text-emerald-300">طالب ملتزم وجيد (الأخضر)</span>
              </div>
              <div className="font-mono font-black text-white">
                {stats.green} طالب ({getPercent(stats.green)}%)
              </div>
            </div>

            {/* Yellow */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[#0D131F] border border-amber-500/20 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-400 shadow-xs shadow-amber-500" />
                <span className="font-bold text-amber-300">تنبيه أولي - خصم 5 درجات (الأصفر)</span>
              </div>
              <div className="font-mono font-black text-white">
                {stats.yellow} طالب ({getPercent(stats.yellow)}%)
              </div>
            </div>

            {/* Orange */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[#0D131F] border border-orange-500/20 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-orange-400 shadow-xs shadow-orange-500" />
                <span className="font-bold text-orange-300">تكرار عدم الالتزام - خصم 10 درجات (البرتقالي)</span>
              </div>
              <div className="font-mono font-black text-white">
                {stats.orange} طالب ({getPercent(stats.orange)}%)
              </div>
            </div>

            {/* Red */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-[#0D131F] border border-rose-500/30 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-500 shadow-xs shadow-rose-500" />
                <span className="font-bold text-rose-300">خصومات متكررة - خصم 15 درجة (الأحمر)</span>
              </div>
              <div className="font-mono font-black text-white">
                {stats.red} طالب ({getPercent(stats.red)}%)
              </div>
            </div>

            {/* Dark Red */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-rose-950/40 border border-rose-700 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-300 animate-pulse" />
                <span className="font-black text-rose-200">حالة حرجة - أقصى خصم 20 درجة (الأحمر الداكن)</span>
              </div>
              <div className="font-mono font-black text-rose-200">
                {stats.darkRed} طالب ({getPercent(stats.darkRed)}%)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Honor Roll: Top Achievers in Art Education */}
      {stats.topStudents.length > 0 && (
        <div className="p-6 rounded-3xl bg-[#161F30] border border-slate-800 space-y-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Sparkles className="w-5 h-5 text-amber-400" />
              </div>
              <h3 className="font-black text-sm text-white">لوحة شرف الأوائل والمتميزين في التربية الفنية</h3>
            </div>
            <span className="text-[10px] text-amber-400 font-bold">أعلى الدرجات المرصودة</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {stats.topStudents.map((item, idx) => (
              <div
                key={item.student.id}
                className="p-3.5 rounded-2xl bg-[#0D131F] border border-amber-500/30 text-center space-y-2 relative"
              >
                <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs mx-auto flex items-center justify-center border border-amber-500/40">
                  {idx + 1}
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-white truncate">{item.student.fullName}</h4>
                  <span className="text-[10px] font-mono text-slate-400">{item.student.studentNumber}</span>
                </div>
                <div className="text-lg font-black text-amber-400">{item.score} درجة</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
