import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  Plus,
  Search,
  Edit2,
  Trash2,
  Award,
  Layers,
  Users,
  Palette,
  X,
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import { TalentDomain, GiftedStudent } from '../../types';
import { formatIraqiDate, formatShortDate } from '../../utils/dateUtils';

const STANDARD_DOMAINS: TalentDomain[] = [
  'الرسم',
  'التلوين',
  'الخط العربي',
  'التصميم',
  'الأعمال اليدوية',
  'مجال مخصص',
];

export const GiftedStudentsScreen: React.FC = () => {
  const {
    classes,
    sections,
    students,
    giftedStudents,
    addGiftedStudent,
    updateGiftedStudent,
    removeGiftedStudent,
    selectedClassId,
    setSelectedClassId,
    selectedSectionId,
    setSelectedSectionId,
    profile,
  } = useTeacherApp();

  const [selectedDomain, setSelectedDomain] = useState<string>('الكل');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [formStudentId, setFormStudentId] = useState('');
  const [formDomain, setFormDomain] = useState<string>('الرسم');
  const [formCustomDomain, setFormCustomDomain] = useState('');
  const [formDiscoveryDate, setFormDiscoveryDate] = useState(new Date().toISOString().slice(0, 10));
  const [formNotes, setFormNotes] = useState('');
  const [formParticipations, setFormParticipations] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);

  // All gifted student items joined with student profile
  const allGiftedList = useMemo(() => {
    return Object.values(giftedStudents).map((entry) => {
      const student = students.find((s) => s.id === entry.studentId);
      const cls = classes.find((c) => c.id === student?.classId);
      const sec = sections.find((s) => s.id === student?.sectionId);

      return {
        ...entry,
        student,
        className: cls?.name || 'غير محدد',
        sectionName: sec?.name || 'غير محدد',
        classId: student?.classId || '',
        sectionId: student?.sectionId || '',
      };
    });
  }, [giftedStudents, students, classes, sections]);

  // Filtered
  const filteredGiftedList = useMemo(() => {
    return allGiftedList.filter((item) => {
      if (selectedClassId && item.classId !== selectedClassId) return false;
      if (selectedSectionId && item.sectionId !== selectedSectionId) return false;
      if (selectedDomain !== 'الكل' && item.talentDomain !== selectedDomain) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.student?.fullName.toLowerCase().includes(q) ?? false;
        const matchDomain = item.talentDomain.toLowerCase().includes(q);
        const matchNotes = item.teacherNotes.toLowerCase().includes(q);
        if (!matchName && !matchDomain && !matchNotes) return false;
      }

      return true;
    });
  }, [allGiftedList, selectedClassId, selectedSectionId, selectedDomain, searchQuery]);

  // Available students to add (not yet in gifted registry for this section)
  const availableStudentsToAdd = useMemo(() => {
    const giftedSet = new Set(Object.keys(giftedStudents));
    return students.filter(
      (s) =>
        (!selectedClassId || s.classId === selectedClassId) &&
        (!selectedSectionId || s.sectionId === selectedSectionId) &&
        !s.archived &&
        !giftedSet.has(s.id)
    );
  }, [students, selectedClassId, selectedSectionId, giftedStudents]);

  const openAddModal = () => {
    setEditingStudentId(null);
    setFormStudentId(availableStudentsToAdd[0]?.id || '');
    setFormDomain('الرسم');
    setFormCustomDomain('');
    setFormDiscoveryDate(new Date().toISOString().slice(0, 10));
    setFormNotes('');
    setFormParticipations('');
    setIsAddModalOpen(true);
  };

  const openEditModal = (entry: GiftedStudent) => {
    setEditingStudentId(entry.studentId);
    setFormStudentId(entry.studentId);
    if (STANDARD_DOMAINS.includes(entry.talentDomain as TalentDomain)) {
      setFormDomain(entry.talentDomain);
      setFormCustomDomain('');
    } else {
      setFormDomain('مجال مخصص');
      setFormCustomDomain(entry.talentDomain);
    }
    setFormDiscoveryDate(entry.discoveryDate);
    setFormNotes(entry.teacherNotes);
    setFormParticipations(entry.participations);
    setIsAddModalOpen(true);
  };

  const handleSaveGifted = (e: React.FormEvent) => {
    e.preventDefault();
    const finalDomain = formDomain === 'مجال مخصص' ? formCustomDomain.trim() || 'مجال مخصص' : formDomain;

    if (editingStudentId) {
      updateGiftedStudent(editingStudentId, {
        talentDomain: finalDomain,
        discoveryDate: formDiscoveryDate,
        teacherNotes: formNotes.trim(),
        participations: formParticipations.trim(),
      });
      setToastMessage('تم تحديث بيانات الطالب الموهوب بنجاح.');
    } else {
      if (!formStudentId) return;
      addGiftedStudent({
        studentId: formStudentId,
        talentDomain: finalDomain,
        discoveryDate: formDiscoveryDate,
        teacherNotes: formNotes.trim(),
        participations: formParticipations.trim(),
      });
      setToastMessage('تمت إضافة الطالب إلى سجل الموهوبين بنجاح.');
    }

    setIsAddModalOpen(false);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (studentId: string) => {
    if (window.confirm('هل أنت متأكد من إزالة هذا الطالب من سجل الموهوبين؟')) {
      removeGiftedStudent(studentId);
      setToastMessage('تمت إزالة الطالب من السجل.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 p-4 rounded-2xl bg-teal-600 text-white font-bold text-xs shadow-2xl border border-teal-400/40 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-white shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 text-amber-300 text-xs font-bold border border-amber-500/30 mb-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>رعاية وتوثيق المواهب الفنية العراقية</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>قسم الطلبة الموهوبين (التربية الفنية)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            سجل مخصص لتوثيق ومتابعة مواهب الطلبة في الرسم، الخط العربي، الأعمال اليدوية، التصميم، ومشاركاتهم في معارض مديرية التربية.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black text-xs transition-all shadow-lg shadow-amber-950/40 flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
          <span>إضافة طالب موهوب</span>
        </button>
      </div>

      {/* Filters Toolbar */}
      <div className="p-4 rounded-3xl bg-[#161F30] border border-slate-800 space-y-3 shadow-md">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Class Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الصف</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                const firstSec = sections.find((s) => s.classId === e.target.value);
                if (firstSec) setSelectedSectionId(firstSec.id);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              <option value="">كافة الصفوف</option>
              {activeClasses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشعبة</label>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              <option value="">كافة الشعب</option>
              {activeSections.map((sec) => (
                <option key={sec.id} value={sec.id}>
                  شعبة {sec.name}
                </option>
              ))}
            </select>
          </div>

          {/* Domain Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">مجال الموهبة</label>
            <select
              value={selectedDomain}
              onChange={(e) => setSelectedDomain(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              <option value="الكل">كافة المجالات الفنية</option>
              {STANDARD_DOMAINS.map((dom) => (
                <option key={dom} value={dom}>
                  {dom}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث بالاسم أو المجال..."
              className="w-full pr-9 pl-3 py-1.5 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
            />
          </div>

          <span className="text-xs text-slate-400 font-bold">
            عدد الموهوبين المسجلين: <b className="text-amber-400">{filteredGiftedList.length}</b>
          </span>
        </div>
      </div>

      {/* Gifted Students Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredGiftedList.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-[#161F30] rounded-3xl border border-slate-800 space-y-3">
            <Sparkles className="w-10 h-10 text-amber-500/60 mx-auto" />
            <h4 className="text-sm font-bold text-slate-200">لا يوجد طلبة مسجلين في قسم الموهوبين حالياً</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              اضغط على زر "إضافة طالب موهوب" لتوثيق مواهب متميزة في الرسم والخط والأعمال اليدوية.
            </p>
          </div>
        ) : (
          filteredGiftedList.map((entry) => (
            <div
              key={entry.studentId}
              className="p-5 rounded-3xl bg-[#161F30] border border-slate-800 hover:border-amber-500/40 transition-all space-y-4 shadow-md relative overflow-hidden group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-base text-white">
                      {entry.student?.fullName || 'طالب غير معروف'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded-md">
                      {entry.student?.studentNumber}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span>{entry.className}</span>
                    <span>•</span>
                    <span>شعبة {entry.sectionName}</span>
                  </div>
                </div>

                {/* Domain Pill */}
                <div className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-extrabold text-xs flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-amber-400" />
                  <span>{entry.talentDomain}</span>
                </div>
              </div>

              {/* Teacher Notes & Style */}
              {entry.teacherNotes && (
                <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-xs text-slate-300 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 block">
                    ملاحظات أستاذ التربية الفنية:
                  </span>
                  <p className="leading-relaxed">{entry.teacherNotes}</p>
                </div>
              )}

              {/* Participations */}
              {entry.participations && (
                <div className="p-3 rounded-2xl bg-teal-950/20 border border-teal-800/40 text-xs text-teal-300 space-y-1">
                  <span className="text-[10px] font-bold text-teal-400 flex items-center gap-1">
                    <Award className="w-3 h-3 text-teal-400" />
                    <span>المشاركات والمعارض والجوائز:</span>
                  </span>
                  <p className="leading-relaxed">{entry.participations}</p>
                </div>
              )}

              {/* Footer with discovery date and action buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <span className="text-[10px] text-slate-500">
                  تاريخ التوثيق: {formatShortDate(entry.discoveryDate)}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(entry)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="تعديل"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(entry.studentId)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                    title="إزالة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Gifted Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <form
            onSubmit={handleSaveGifted}
            className="bg-[#161F30] border border-slate-700 w-full max-w-lg rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>{editingStudentId ? 'تعديل بيانات الطالب الموهوب' : 'إضافة طالب إلى سجل الموهوبين'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Select Student (if creating new) */}
            {!editingStudentId ? (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اختر الطالب من القائمة <span className="text-rose-400">*</span>
                </label>
                <select
                  required
                  value={formStudentId}
                  onChange={(e) => setFormStudentId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
                >
                  <option value="">-- اختر طالباً --</option>
                  {availableStudentsToAdd.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.studentNumber})
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="text-xs font-bold text-sky-400">
                الطالب: {students.find((s) => s.id === formStudentId)?.fullName}
              </div>
            )}

            {/* Domain */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                مجال الموهبة الفنية <span className="text-rose-400">*</span>
              </label>
              <select
                value={formDomain}
                onChange={(e) => setFormDomain(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
              >
                {STANDARD_DOMAINS.map((dom) => (
                  <option key={dom} value={dom}>
                    {dom}
                  </option>
                ))}
              </select>
            </div>

            {formDomain === 'مجال مخصص' && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  حدد المجال المخصص <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formCustomDomain}
                  onChange={(e) => setFormCustomDomain(e.target.value)}
                  placeholder="مثال: النحت على الطين، الخزف، الزخرفة الإسلامية..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
                />
              </div>
            )}

            {/* Discovery Date */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                تاريخ اكتشاف الموهبة أو التسجيل
              </label>
              <input
                type="date"
                value={formDiscoveryDate}
                onChange={(e) => setFormDiscoveryDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-mono focus:outline-hidden"
              />
            </div>

            {/* Teacher Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                ملاحظات المعلم وتقييم المهارة
              </label>
              <textarea
                rows={2}
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                placeholder="أبرز مهارات الطالب (مثل: التحكم بالألوان، التظليل، دقة الخط...)"
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
              />
            </div>

            {/* Participations */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                المشاركات والمعارض والأنشطة
              </label>
              <textarea
                rows={2}
                value={formParticipations}
                onChange={(e) => setFormParticipations(e.target.value)}
                placeholder="معرض المدرسة السنوي، مسابقة الخط بالمديرية، لوحات معروضة..."
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-lg cursor-pointer"
              >
                حفظ في سجل الموهوبين
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
