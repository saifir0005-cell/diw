import React, { useState, useMemo } from 'react';
import {
  Palette,
  CalendarCheck2,
  Save,
  CheckCircle2,
  Info,
  Calendar,
  Layers,
  Sparkles,
  Check,
  X,
  HelpCircle,
  Eye,
  SlidersHorizontal,
  ChevronDown,
  ShieldAlert,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import { DetailedArtGradeRecord, AttendanceStatus, MainNavScreen } from '../../types';
import {
  getDetailedCalculationBreakdown,
  CalculationDetails,
  getCommitmentInfo,
} from '../../utils/gradingEngine';
import { getTodayDateString, formatIraqiDate, formatHijriDate } from '../../utils/dateUtils';

type GradebookViewTab = 'all_columns' | 'semester_1' | 'midyear' | 'semester_2' | 'annual';

export const GradebookScreen: React.FC = () => {
  const {
    classes,
    sections,
    students,
    grades,
    updateGradeField,
    batchSaveGrades,
    getStudentGrade,
    attendance,
    saveDayAttendance,
    getAttendanceForDate,
    compliances,
    getAllStudentCompliances,
    getStudentMonthlyCompliance,
    setActiveScreen,
    selectedClassId,
    setSelectedClassId,
    selectedSectionId,
    setSelectedSectionId,
    selectedDate,
    setSelectedDate,
    gradingConfig,
    profile,
  } = useTeacherApp();

  // Mode: Gradebook vs Attendance
  const [activeSubMode, setActiveSubMode] = useState<'gradebook' | 'attendance'>('gradebook');
  const [viewTab, setViewTab] = useState<GradebookViewTab>('all_columns');

  // Calculation details modal
  const [activeCalculationRecord, setActiveCalculationRecord] = useState<DetailedArtGradeRecord | null>(null);

  // Success indicator
  const [showSaveAlert, setShowSaveAlert] = useState(false);

  // Available classes & sections
  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);

  // Section Students
  const sectionStudents = useMemo(() => {
    return students.filter(
      (s) => s.classId === selectedClassId && s.sectionId === selectedSectionId && !s.archived && s.status === 'مستمر'
    );
  }, [students, selectedClassId, selectedSectionId]);

  // Attendance for selected date
  const dayAttendanceMap = useMemo(() => {
    return getAttendanceForDate(selectedClassId, selectedSectionId, selectedDate);
  }, [selectedClassId, selectedSectionId, selectedDate, getAttendanceForDate]);

  // Attendance local draft state
  const [attendanceDraft, setAttendanceDraft] = useState<Record<string, AttendanceStatus>>({});

  // Sync draft when date or section changes
  React.useEffect(() => {
    const draft: Record<string, AttendanceStatus> = {};
    sectionStudents.forEach((std) => {
      draft[std.id] = dayAttendanceMap[std.id]?.status || 'حاضر';
    });
    setAttendanceDraft(draft);
  }, [selectedClassId, selectedSectionId, selectedDate, dayAttendanceMap, sectionStudents]);

  // Grade Input Change
  const handleNumericGradeChange = (
    studentId: string,
    field: keyof DetailedArtGradeRecord,
    valStr: string,
    maxVal: number = 100
  ) => {
    if (valStr === '') {
      updateGradeField(studentId, field, null);
      return;
    }
    const num = Math.min(maxVal, Math.max(0, Number(valStr)));
    updateGradeField(studentId, field, isNaN(num) ? null : num);
  };

  // Mark all present
  const handleMarkAllPresent = () => {
    const updated: Record<string, AttendanceStatus> = {};
    sectionStudents.forEach((std) => {
      updated[std.id] = 'حاضر';
    });
    setAttendanceDraft(updated);
  };

  // Save attendance
  const handleSaveAttendance = () => {
    const records = sectionStudents.map((std) => ({
      studentId: std.id,
      status: attendanceDraft[std.id] || 'حاضر',
    }));
    saveDayAttendance(selectedClassId, selectedSectionId, selectedDate, records);
    setShowSaveAlert(true);
    setTimeout(() => setShowSaveAlert(false), 2500);
  };

  const selectedClass = classes.find((c) => c.id === selectedClassId);
  const selectedSection = sections.find((s) => s.id === selectedSectionId);

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Top Header & Mode Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            {activeSubMode === 'gradebook' ? (
              <Palette className="w-6 h-6 text-amber-400" />
            ) : (
              <CalendarCheck2 className="w-6 h-6 text-teal-400" />
            )}
            <span>{activeSubMode === 'gradebook' ? 'سجل درجات التربية الفنية' : 'سجل الحضور والغياب اليومي'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {activeSubMode === 'gradebook'
              ? 'إدخال سريع لدرجات الشهور، السعي الفصلي، ونصف السنة، والسعي السنوي'
              : 'رصد الحضور اليومي وتثبيت الغيابات بدون عذر والإجازات'}
          </p>
        </div>

        {/* Mode Switcher Pill */}
        <div className="flex p-1 bg-[#161F30] border border-slate-800 rounded-2xl">
          <button
            onClick={() => setActiveSubMode('gradebook')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeSubMode === 'gradebook'
                ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>سجل الدرجات</span>
          </button>
          <button
            onClick={() => setActiveSubMode('attendance')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeSubMode === 'attendance'
                ? 'bg-teal-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CalendarCheck2 className="w-4 h-4" />
            <span>تسجيل الغياب</span>
          </button>
        </div>
      </div>

      {/* Save Success Alert */}
      {showSaveAlert && (
        <div className="p-3.5 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span>تم حفظ السجل بنجاح في قاعدة البيانات المحلية.</span>
        </div>
      )}

      {/* Section Selector Toolbar */}
      <div className="p-4 rounded-3xl bg-[#161F30] border border-slate-800 space-y-3 shadow-md">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Class */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الصف الدراسي</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                const firstSec = sections.find((s) => s.classId === e.target.value);
                if (firstSec) setSelectedSectionId(firstSec.id);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeClasses.length === 0 ? (
                <option value="">لا توجد صفوف مضافة</option>
              ) : (
                activeClasses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))
              )}
            </select>
          </div>

          {/* Section */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشعبة</label>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeSections.length === 0 ? (
                <option value="">لا توجد شعب مضافة</option>
              ) : (
                activeSections.map((sec) => (
                  <option key={sec.id} value={sec.id}>
                    شعبة {sec.name}
                  </option>
                ))
              )}
            </select>
          </div>

          {/* Date Picker (if in Attendance mode) or View Column Mode (if in Gradebook mode) */}
          {activeSubMode === 'attendance' ? (
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">تاريخ الحضور</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-mono focus:outline-hidden"
              />
            </div>
          ) : (
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">عرض الأعمدة</label>
              <select
                value={viewTab}
                onChange={(e) => setViewTab(e.target.value as GradebookViewTab)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
              >
                <option value="all_columns">عرض السجل الشامل (كافة الأعمدة)</option>
                <option value="semester_1">الفصل الأول (شهر 1 + شهر 2 + السعي)</option>
                <option value="midyear">امتحان نصف السنة</option>
                <option value="semester_2">الفصل الثاني (شهر 1 + شهر 2 + السعي)</option>
                <option value="annual">النتائج السنوية والنهائية</option>
              </select>
            </div>
          )}
        </div>

        {/* Info bar */}
        <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span>
              الطلبة المسجلين: <b className="text-white">{sectionStudents.length}</b>
            </span>
            {activeSubMode === 'attendance' && (
              <span className="text-amber-400 font-medium">
                {formatHijriDate(selectedDate)}
              </span>
            )}
          </div>

          {activeSubMode === 'attendance' ? (
            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkAllPresent}
                className="px-3 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-bold cursor-pointer"
              >
                تسجيل الكل حاضر ✓
              </button>
              <button
                onClick={handleSaveAttendance}
                className="px-4 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold cursor-pointer shadow-md"
              >
                حفظ الحضور
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveScreen('non_compliance')}
                className="px-3 py-1 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>متابعة غير الملتزم والخصومات</span>
              </button>
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-sky-400" />
                <span>الحفظ والحساب التلقائي يعمل لحظياً مع كل رقم تدخله</span>
              </span>
            </div>
          )}
        </div>
      </div>

      {/* ===================== GRADEBOOK SPREADSHEET TABLE ===================== */}
      {activeSubMode === 'gradebook' && (
        <div className="rounded-3xl bg-[#161F30] border border-slate-800 shadow-xl overflow-hidden">
          {sectionStudents.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <Palette className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-bold text-slate-300">لا يوجد طلبة في هذه الشعبة</h4>
              <p className="text-xs text-slate-500">
                اختر شعبة أخرى أو أضف طلبة في قسم "سجل الطلبة"
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto relative">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  {/* Top Header Grouping */}
                  <tr className="bg-[#0D131F] text-slate-300 text-[11px] font-black border-b border-slate-800 text-center">
                    <th className="py-2.5 px-3 sticky right-0 z-20 bg-[#0D131F] min-w-[170px] text-right border-l border-slate-800">
                      اسم الطالب
                    </th>

                    {(viewTab === 'all_columns' || viewTab === 'semester_1') && (
                      <th colSpan={7} className="py-2 px-2 bg-sky-950/50 text-sky-300 border-l border-slate-800">
                        الفصل الدراسي الأول
                      </th>
                    )}

                    {(viewTab === 'all_columns' || viewTab === 'midyear') && (
                      <th className="py-2 px-2 bg-indigo-950/60 text-indigo-300 border-l border-slate-800 min-w-[85px]">
                        نصف السنة
                      </th>
                    )}

                    {(viewTab === 'all_columns' || viewTab === 'semester_2') && (
                      <th colSpan={7} className="py-2 px-2 bg-teal-950/50 text-teal-300 border-l border-slate-800">
                        الفصل الدراسي الثاني
                      </th>
                    )}

                    {(viewTab === 'all_columns' || viewTab === 'annual') && (
                      <th colSpan={4} className="py-2 px-2 bg-amber-950/50 text-amber-300 border-l border-slate-800">
                        النتائج السنوية النهائية
                      </th>
                    )}

                    <th className="py-2 px-2 min-w-[70px]">تفاصيل</th>
                  </tr>

                  {/* Column Header Titles */}
                  <tr className="bg-[#111827] text-slate-400 text-[10px] font-bold border-b border-slate-800 text-center">
                    <th className="py-2 px-3 sticky right-0 z-20 bg-[#111827] text-right border-l border-slate-800">
                      الرقم والاسم
                    </th>

                    {/* Semester 1 Columns */}
                    {(viewTab === 'all_columns' || viewTab === 'semester_1') && (
                      <>
                        <th className="py-2 px-1 min-w-[55px]">شفهي 1</th>
                        <th className="py-2 px-1 min-w-[55px]">تحريري 1</th>
                        <th className="py-2 px-1 min-w-[55px] bg-slate-800/50 text-sky-300">معدل 1</th>
                        <th className="py-2 px-1 min-w-[55px]">شفهي 2</th>
                        <th className="py-2 px-1 min-w-[55px]">تحريري 2</th>
                        <th className="py-2 px-1 min-w-[55px] bg-slate-800/50 text-sky-300">معدل 2</th>
                        <th className="py-2 px-1 min-w-[65px] bg-sky-900/40 text-sky-200 font-black border-l border-slate-800">
                          سعي ف1
                        </th>
                      </>
                    )}

                    {/* Midyear */}
                    {(viewTab === 'all_columns' || viewTab === 'midyear') && (
                      <th className="py-2 px-1 min-w-[65px] bg-indigo-900/40 text-indigo-200 font-black border-l border-slate-800">
                        نصف السنة
                      </th>
                    )}

                    {/* Semester 2 Columns */}
                    {(viewTab === 'all_columns' || viewTab === 'semester_2') && (
                      <>
                        <th className="py-2 px-1 min-w-[55px]">شفهي 1</th>
                        <th className="py-2 px-1 min-w-[55px]">تحريري 1</th>
                        <th className="py-2 px-1 min-w-[55px] bg-slate-800/50 text-teal-300">معدل 1</th>
                        <th className="py-2 px-1 min-w-[55px]">شفهي 2</th>
                        <th className="py-2 px-1 min-w-[55px]">تحريري 2</th>
                        <th className="py-2 px-1 min-w-[55px] bg-slate-800/50 text-teal-300">معدل 2</th>
                        <th className="py-2 px-1 min-w-[65px] bg-teal-900/40 text-teal-200 font-black border-l border-slate-800">
                          سعي ف2
                        </th>
                      </>
                    )}

                    {/* Annual Results */}
                    {(viewTab === 'all_columns' || viewTab === 'annual') && (
                      <>
                        <th className="py-2 px-1 min-w-[65px] bg-amber-900/40 text-amber-200 font-black">
                          السعي السنوي
                        </th>
                        <th className="py-2 px-1 min-w-[60px]">نهائي</th>
                        <th className="py-2 px-1 min-w-[65px] bg-amber-500/20 text-amber-300 font-black">
                          النهائية
                        </th>
                        <th className="py-2 px-2 min-w-[65px] border-l border-slate-800">
                          الحالة
                        </th>
                      </>
                    )}

                    <th className="py-2 px-1">القاعدة</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-800 text-slate-200 text-xs">
                  {sectionStudents.map((std, idx) => {
                    const g = getStudentGrade(std.id);
                    const allComp = getAllStudentCompliances(std.id);
                    const commitment = getCommitmentInfo(allComp);
                    const c1 = getStudentMonthlyCompliance(std.id, 1);
                    const d1 = c1.totalDeduction;
                    const c2 = getStudentMonthlyCompliance(std.id, 2);
                    const d2 = c2.totalDeduction;
                    const c3 = getStudentMonthlyCompliance(std.id, 3);
                    const d3 = c3.totalDeduction;
                    const c4 = getStudentMonthlyCompliance(std.id, 4);
                    const d4 = c4.totalDeduction;

                    return (
                      <tr key={std.id} className="hover:bg-[#1E2B42]/40 transition-colors">
                        {/* Sticky Name Column with Graded Color Indicator */}
                        <td className="py-2 px-3 sticky right-0 z-10 bg-[#161F30] border-l border-slate-800">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`w-2 h-2 rounded-full shrink-0 ${
                                commitment.level === 'green'
                                  ? 'bg-emerald-400'
                                  : commitment.level === 'yellow'
                                  ? 'bg-amber-400'
                                  : commitment.level === 'orange'
                                  ? 'bg-orange-400'
                                  : commitment.level === 'red'
                                  ? 'bg-rose-500'
                                  : 'bg-rose-300 animate-pulse'
                              }`}
                              title={commitment.label}
                            />
                            <div className="font-extrabold text-white text-xs truncate max-w-[150px]">
                              {std.fullName}
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                            <span className="font-mono">{std.studentNumber}</span>
                            <span
                              className={`text-[9px] font-bold cursor-pointer hover:underline ${commitment.colorClass}`}
                              onClick={() => setActiveScreen('non_compliance')}
                              title="انقر لفتح قسم غير الملتزم ومتابعة الانضباط"
                            >
                              {commitment.level === 'green' ? '🟢 ملتزم' : `خصم: -${commitment.totalDeduction}`}
                            </span>
                          </div>
                        </td>

                        {/* Semester 1 Inputs */}
                        {(viewTab === 'all_columns' || viewTab === 'semester_1') && (
                          <>
                            {/* Oral M1 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.oralM1 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'oralM1', e.target.value)
                                }
                                placeholder="-"
                                className="w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border border-slate-700 text-white focus:border-sky-400"
                              />
                            </td>

                            {/* Exam M1 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.rawExamM1 ?? g.examM1 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'examM1', e.target.value)
                                }
                                placeholder="-"
                                className={`w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border ${
                                  d1 > 0 ? 'border-rose-500/80 text-rose-200' : 'border-slate-700 text-white'
                                } focus:border-sky-400`}
                              />
                              {d1 > 0 && (
                                <div
                                  onClick={() => setActiveScreen('non_compliance')}
                                  className="text-[9px] text-rose-400 font-bold cursor-pointer hover:underline"
                                  title="خصم عدم التزام نشط. انقر لفتح السجل"
                                >
                                  {g.rawExamM1 !== null && g.rawExamM1 !== undefined
                                    ? `صافي: ${g.examM1} (-${d1})`
                                    : `خصم: -${d1}`}
                                </div>
                              )}
                            </td>

                            {/* Avg M1 (Calculated) */}
                            <td className="p-1 text-center font-bold text-sky-300 bg-slate-900/40">
                              {g.avgM1 ?? '-'}
                            </td>

                            {/* Oral M2 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.oralM2 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'oralM2', e.target.value)
                                }
                                placeholder="-"
                                className="w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border border-slate-700 text-white focus:border-sky-400"
                              />
                            </td>

                            {/* Exam M2 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.rawExamM2 ?? g.examM2 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'examM2', e.target.value)
                                }
                                placeholder="-"
                                className={`w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border ${
                                  d2 > 0 ? 'border-rose-500/80 text-rose-200' : 'border-slate-700 text-white'
                                } focus:border-sky-400`}
                              />
                              {d2 > 0 && (
                                <div
                                  onClick={() => setActiveScreen('non_compliance')}
                                  className="text-[9px] text-rose-400 font-bold cursor-pointer hover:underline"
                                  title="خصم عدم التزام نشط. انقر لفتح السجل"
                                >
                                  {g.rawExamM2 !== null && g.rawExamM2 !== undefined
                                    ? `صافي: ${g.examM2} (-${d2})`
                                    : `خصم: -${d2}`}
                                </div>
                              )}
                            </td>

                            {/* Avg M2 (Calculated) */}
                            <td className="p-1 text-center font-bold text-sky-300 bg-slate-900/40">
                              {g.avgM2 ?? '-'}
                            </td>

                            {/* Sem 1 Pursuit (Calculated) */}
                            <td className="p-1 text-center font-black text-sky-300 bg-sky-950/30 border-l border-slate-800">
                              {g.sem1Pursuit ?? '-'}
                            </td>
                          </>
                        )}

                        {/* Midyear Exam */}
                        {(viewTab === 'all_columns' || viewTab === 'midyear') && (
                          <td className="p-1 text-center bg-indigo-950/20 border-l border-slate-800">
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={g.midYearExam ?? ''}
                              onChange={(e) =>
                                handleNumericGradeChange(std.id, 'midYearExam', e.target.value)
                              }
                              placeholder="-"
                              className="w-14 py-1 px-1 text-center font-black text-xs rounded-lg bg-[#0D131F] border border-indigo-700 text-indigo-200 focus:border-indigo-400"
                            />
                          </td>
                        )}

                        {/* Semester 2 Inputs */}
                        {(viewTab === 'all_columns' || viewTab === 'semester_2') && (
                          <>
                            {/* Oral M3 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.oralM3 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'oralM3', e.target.value)
                                }
                                placeholder="-"
                                className="w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border border-slate-700 text-white focus:border-teal-400"
                              />
                            </td>

                            {/* Exam M3 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.rawExamM3 ?? g.examM3 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'examM3', e.target.value)
                                }
                                placeholder="-"
                                className={`w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border ${
                                  d3 > 0 ? 'border-rose-500/80 text-rose-200' : 'border-slate-700 text-white'
                                } focus:border-teal-400`}
                              />
                              {d3 > 0 && (
                                <div
                                  onClick={() => setActiveScreen('non_compliance')}
                                  className="text-[9px] text-rose-400 font-bold cursor-pointer hover:underline"
                                  title="خصم عدم التزام نشط. انقر لفتح السجل"
                                >
                                  {g.rawExamM3 !== null && g.rawExamM3 !== undefined
                                    ? `صافي: ${g.examM3} (-${d3})`
                                    : `خصم: -${d3}`}
                                </div>
                              )}
                            </td>

                            {/* Avg M3 */}
                            <td className="p-1 text-center font-bold text-teal-300 bg-slate-900/40">
                              {g.avgM3 ?? '-'}
                            </td>

                            {/* Oral M4 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.oralM4 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'oralM4', e.target.value)
                                }
                                placeholder="-"
                                className="w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border border-slate-700 text-white focus:border-teal-400"
                              />
                            </td>

                            {/* Exam M4 */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.rawExamM4 ?? g.examM4 ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'examM4', e.target.value)
                                }
                                placeholder="-"
                                className={`w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border ${
                                  d4 > 0 ? 'border-rose-500/80 text-rose-200' : 'border-slate-700 text-white'
                                } focus:border-teal-400`}
                              />
                              {d4 > 0 && (
                                <div
                                  onClick={() => setActiveScreen('non_compliance')}
                                  className="text-[9px] text-rose-400 font-bold cursor-pointer hover:underline"
                                  title="خصم عدم التزام نشط. انقر لفتح السجل"
                                >
                                  {g.rawExamM4 !== null && g.rawExamM4 !== undefined
                                    ? `صافي: ${g.examM4} (-${d4})`
                                    : `خصم: -${d4}`}
                                </div>
                              )}
                            </td>

                            {/* Avg M4 */}
                            <td className="p-1 text-center font-bold text-teal-300 bg-slate-900/40">
                              {g.avgM4 ?? '-'}
                            </td>

                            {/* Sem 2 Pursuit */}
                            <td className="p-1 text-center font-black text-teal-300 bg-teal-950/30 border-l border-slate-800">
                              {g.sem2Pursuit ?? '-'}
                            </td>
                          </>
                        )}

                        {/* Annual Results */}
                        {(viewTab === 'all_columns' || viewTab === 'annual') && (
                          <>
                            {/* Annual Pursuit (Calculated) */}
                            <td className="p-1 text-center font-black text-amber-300 bg-amber-950/20">
                              {g.annualPursuit ?? '-'}
                            </td>

                            {/* Final Exam Input */}
                            <td className="p-1 text-center">
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={g.finalExam ?? ''}
                                onChange={(e) =>
                                  handleNumericGradeChange(std.id, 'finalExam', e.target.value)
                                }
                                placeholder="-"
                                className="w-12 py-1 px-1 text-center font-bold text-xs rounded-lg bg-[#0D131F] border border-slate-700 text-white focus:border-amber-400"
                              />
                            </td>

                            {/* Final Grade */}
                            <td className="p-1 text-center font-black text-sm bg-amber-500/10">
                              <span
                                className={
                                  g.finalGrade === null
                                    ? 'text-slate-500'
                                    : g.finalGrade >= gradingConfig.minPassingGrade
                                    ? 'text-teal-400'
                                    : 'text-rose-400'
                                }
                              >
                                {g.finalGrade ?? '-'}
                              </span>
                            </td>

                            {/* Result Status */}
                            <td className="p-1 text-center border-l border-slate-800">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  g.resultStatus === 'ناجح'
                                    ? 'bg-teal-500/20 text-teal-300'
                                    : g.resultStatus === 'مكمل'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {g.resultStatus}
                              </span>
                            </td>
                          </>
                        )}

                        {/* Detailed Calculation Inspector */}
                        <td className="p-1 text-center">
                          <button
                            onClick={() => setActiveCalculationRecord(g)}
                            className="p-1 text-slate-400 hover:text-sky-400 transition-colors cursor-pointer"
                            title="تفاصيل معادلة الحساب والقواعد المطبقة"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ===================== DAILY ATTENDANCE TABLE ===================== */}
      {activeSubMode === 'attendance' && (
        <div className="rounded-3xl bg-[#161F30] border border-slate-800 shadow-xl overflow-hidden">
          {sectionStudents.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <CalendarCheck2 className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-bold text-slate-300">لا يوجد طلبة في هذه الشعبة</h4>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-[#111827] text-slate-400 font-bold border-b border-slate-800">
                    <th className="py-3 px-3 text-center w-12">ت</th>
                    <th className="py-3 px-3">الرقم</th>
                    <th className="py-3 px-4">اسم الطالب الرباعي</th>
                    <th className="py-3 px-4 text-center">حالة الحضور</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200 text-xs">
                  {sectionStudents.map((std, idx) => {
                    const st = attendanceDraft[std.id] || 'حاضر';

                    return (
                      <tr key={std.id} className="hover:bg-[#1E2B42]/40 transition-colors">
                        <td className="py-3 px-3 text-center text-slate-500">{idx + 1}</td>
                        <td className="py-3 px-3 font-mono text-sky-400">{std.studentNumber}</td>
                        <td className="py-3 px-4 font-bold text-white">{std.fullName}</td>
                        <td className="py-2 px-4 text-center">
                          <div className="inline-flex rounded-xl bg-[#0D131F] p-1 border border-slate-700 gap-1">
                            <button
                              type="button"
                              onClick={() =>
                                setAttendanceDraft((prev) => ({ ...prev, [std.id]: 'حاضر' }))
                              }
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                st === 'حاضر'
                                  ? 'bg-teal-600 text-white shadow-md'
                                  : 'text-slate-400 hover:text-white'
                              }`}
                            >
                              حاضر
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setAttendanceDraft((prev) => ({ ...prev, [std.id]: 'غائب' }))
                              }
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                st === 'غائب'
                                  ? 'bg-rose-600 text-white shadow-md'
                                  : 'text-slate-400 hover:text-white'
                              }`}
                            >
                              غائب
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setAttendanceDraft((prev) => ({ ...prev, [std.id]: 'مجاز' }))
                              }
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                st === 'مجاز'
                                  ? 'bg-sky-600 text-white shadow-md'
                                  : 'text-slate-400 hover:text-white'
                              }`}
                            >
                              مجاز
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setAttendanceDraft((prev) => ({ ...prev, [std.id]: 'متأخر' }))
                              }
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                st === 'متأخر'
                                  ? 'bg-amber-600 text-white shadow-md'
                                  : 'text-slate-400 hover:text-white'
                              }`}
                            >
                              متأخر
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Calculation Details Modal */}
      {activeCalculationRecord && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161F30] border border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-sky-400" />
                <h3 className="font-extrabold text-base text-white">
                  تفاصيل معادلات الحساب والاعتماد الوزاري
                </h3>
              </div>
              <button
                onClick={() => setActiveCalculationRecord(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              {getDetailedCalculationBreakdown(activeCalculationRecord, gradingConfig).map(
                (step, sIdx) => (
                  <div
                    key={sIdx}
                    className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-white">{step.fieldName}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          step.isProvisional
                            ? 'bg-amber-500/15 text-amber-300'
                            : 'bg-teal-500/15 text-teal-300'
                        }`}
                      >
                        {step.isProvisional ? 'حساب مؤقت / غير مكتمل' : 'معتمد رسمياً'}
                      </span>
                    </div>

                    <p className="text-[11px] text-sky-400 font-mono">
                      المعادلة: {step.formula}
                    </p>

                    <div className="flex flex-wrap gap-2 text-[11px] text-slate-300 pt-1">
                      {step.inputs.map((inp, iIdx) => (
                        <span key={iIdx} className="bg-slate-800 px-2 py-0.5 rounded-md">
                          {inp.name}: <b>{inp.value ?? 'غير مدخل'}</b>
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-xs">
                      <span className="text-slate-400 text-[11px]">{step.ruleSet}</span>
                      <span className="font-black text-amber-300">
                        النتيجة: {step.result ?? 'بانتظار الإدخال'}
                      </span>
                    </div>
                  </div>
                )
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setActiveCalculationRecord(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
