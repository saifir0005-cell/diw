import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Printer,
  Download,
  User,
  Users,
  Layers,
  Award,
  Calendar,
  Sparkles,
  FileText,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import { DetailedArtGradeRecord, Student } from '../../types';
import { formatIraqiDate, formatShortDate, formatHijriDate } from '../../utils/dateUtils';
import { getCommitmentInfo } from '../../utils/gradingEngine';

type ReportType = 'individual' | 'section' | 'class' | 'annual_teacher';

export const FinalReportsScreen: React.FC = () => {
  const {
    profile,
    classes,
    sections,
    students,
    grades,
    attendance,
    getAllStudentCompliances,
    selectedClassId,
    setSelectedClassId,
    selectedSectionId,
    setSelectedSectionId,
    getStudentGrade,
    getStudentAttendanceStats,
  } = useTeacherApp();

  const [reportType, setReportType] = useState<ReportType>('section');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');

  // Active classes & sections
  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);

  // Section Students
  const sectionStudents = useMemo(() => {
    return students.filter(
      (s) => s.classId === selectedClassId && s.sectionId === selectedSectionId && !s.archived
    );
  }, [students, selectedClassId, selectedSectionId]);

  // Current selected student
  const activeStudent = useMemo(() => {
    if (selectedStudentId) {
      return students.find((s) => s.id === selectedStudentId);
    }
    return sectionStudents[0];
  }, [students, selectedStudentId, sectionStudents]);

  const selectedClass = classes.find((c) => c.id === selectedClassId);
  const selectedSection = sections.find((s) => s.id === selectedSectionId);

  // Print Action
  const handlePrint = () => {
    window.print();
  };

  // CSV Export
  const handleExportCSV = () => {
    let csv = '\uFEFF';

    if (reportType === 'individual' && activeStudent) {
      const g = getStudentGrade(activeStudent.id);
      const att = getStudentAttendanceStats(activeStudent.id);
      csv += `المدرسة: ${profile.schoolName}\nالأستاذ: ${profile.teacherName}\nالعام الدراسي: ${profile.academicYear}\n\n`;
      csv += `اسم الطالب: ${activeStudent.fullName}, الرقم التسلسلي: ${activeStudent.studentNumber}, الصف: ${selectedClass?.name || ''}, الشعبة: ${selectedSection?.name || ''}\n\n`;
      csv += `المعيار,الدرجة\n`;
      csv += `شفهي شهر 1 (ف1),${g.oralM1 ?? '-'}\n`;
      csv += `تحريري شهر 1 (ف1),${g.examM1 ?? '-'}\n`;
      csv += `معدل شهر 1 (ف1),${g.avgM1 ?? '-'}\n`;
      csv += `شفهي شهر 2 (ف1),${g.oralM2 ?? '-'}\n`;
      csv += `تحريري شهر 2 (ف1),${g.examM2 ?? '-'}\n`;
      csv += `معدل شهر 2 (ف1),${g.avgM2 ?? '-'}\n`;
      csv += `سعي الفصل الأول,${g.sem1Pursuit ?? '-'}\n`;
      csv += `امتحان نصف السنة,${g.midYearExam ?? '-'}\n`;
      csv += `شفهي شهر 1 (ف2),${g.oralM3 ?? '-'}\n`;
      csv += `تحريري شهر 1 (ف2),${g.examM3 ?? '-'}\n`;
      csv += `معدل شهر 1 (ف2),${g.avgM3 ?? '-'}\n`;
      csv += `شفهي شهر 2 (ف2),${g.oralM4 ?? '-'}\n`;
      csv += `تحريري شهر 2 (ف2),${g.examM4 ?? '-'}\n`;
      csv += `معدل شهر 2 (ف2),${g.avgM4 ?? '-'}\n`;
      csv += `سعي الفصل الثاني,${g.sem2Pursuit ?? '-'}\n`;
      csv += `السعي السنوي العام,${g.annualPursuit ?? '-'}\n`;
      csv += `الامتحان النهائي,${g.finalExam ?? '-'}\n`;
      csv += `الدرجة النهائية,${g.finalGrade ?? '-'}\n`;
      csv += `النتيجة,${g.resultStatus}\n`;
      csv += `إجمالي أيام الغياب,${att.totalAbsences}\n`;
    } else {
      csv += `ت,الرقم,اسم الطالب,شفهي1,تحريري1,معدل1,شفهي2,تحريري2,معدل2,سعي ف1,نصف السنة,شفهي1(ف2),تحريري1(ف2),معدل1(ف2),شفهي2(ف2),تحريري2(ف2),معدل2(ف2),سعي ف2,السعي السنوي,نهائي,الدرجة النهائية,النتيجة,الغيابات\n`;

      sectionStudents.forEach((std, idx) => {
        const g = getStudentGrade(std.id);
        const att = getStudentAttendanceStats(std.id);
        csv += `"${idx + 1}","${std.studentNumber}","${std.fullName}","${g.oralM1 ?? ''}","${g.examM1 ?? ''}","${g.avgM1 ?? ''}","${g.oralM2 ?? ''}","${g.examM2 ?? ''}","${g.avgM2 ?? ''}","${g.sem1Pursuit ?? ''}","${g.midYearExam ?? ''}","${g.oralM3 ?? ''}","${g.examM3 ?? ''}","${g.avgM3 ?? ''}","${g.oralM4 ?? ''}","${g.examM4 ?? ''}","${g.avgM4 ?? ''}","${g.sem2Pursuit ?? ''}","${g.annualPursuit ?? ''}","${g.finalExam ?? ''}","${g.finalGrade ?? ''}","${g.resultStatus}","${att.totalAbsences}"\n`;
      });
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `تقرير_${reportType}_${selectedClass?.name || ''}_${selectedSection?.name || ''}_${profile.academicYear}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Top Header - Hidden in Print */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-indigo-400" />
            <span>التقارير النهائية الرسمية</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            توليد كشوفات رسمية معتمدة قابلة للطباعة والتصدير بصيغة A4
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-indigo-400" />
            <span>تصدير CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-950/40 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التقرير (A4)</span>
          </button>
        </div>
      </div>

      {/* Report Controls & Filters - Hidden in Print */}
      <div className="p-4 rounded-3xl bg-[#161F30] border border-slate-800 space-y-4 shadow-md print:hidden">
        {/* Report Types Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => setReportType('individual')}
            className={`p-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              reportType === 'individual'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#111827] text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            <span>أ. كشف الطالب الفردي</span>
          </button>

          <button
            onClick={() => setReportType('section')}
            className={`p-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              reportType === 'section'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#111827] text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>ب. كشف الشعبة الشامل</span>
          </button>

          <button
            onClick={() => setReportType('class')}
            className={`p-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              reportType === 'class'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#111827] text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>ج. كشف الصف الموحد</span>
          </button>

          <button
            onClick={() => setReportType('annual_teacher')}
            className={`p-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              reportType === 'annual_teacher'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#111827] text-slate-400 hover:text-white'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>د. التقرير السنوي الشامل</span>
          </button>
        </div>

        {/* Filter Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800">
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الصف</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                const firstS = sections.find((s) => s.classId === e.target.value);
                if (firstS) setSelectedSectionId(firstS.id);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeClasses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشعبة</label>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeSections.map((sec) => (
                <option key={sec.id} value={sec.id}>
                  شعبة {sec.name}
                </option>
              ))}
            </select>
          </div>

          {reportType === 'individual' && (
            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">اختر الطالب</label>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
              >
                {sectionStudents.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.fullName} ({s.studentNumber})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* ===================== PRINTABLE A4 OFFICIAL REPORT DOCUMENT ===================== */}
      <div className="bg-white text-slate-900 rounded-3xl p-8 sm:p-10 shadow-2xl border border-slate-200 print:border-none print:shadow-none print:p-0 print:rounded-none">
        {/* Official Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6">
          <div className="flex items-center justify-between text-slate-900">
            {/* Right: State & School */}
            <div className="space-y-0.5 text-right">
              <p className="font-extrabold text-sm sm:text-base">جمهورية العراق</p>
              <p className="font-bold text-xs">وزارة التربية</p>
              <p className="font-extrabold text-xs text-slate-800">{profile.schoolName}</p>
              <p className="text-xs text-slate-700">مادة: {profile.subject}</p>
            </div>

            {/* Center: Title & Emblem */}
            <div className="text-center space-y-1">
              <div className="w-11 h-11 mx-auto rounded-full border-2 border-slate-900 flex items-center justify-center font-bold text-base">
                🇮🇶
              </div>
              <h3 className="text-base sm:text-lg font-black underline underline-offset-4">
                {reportType === 'individual' && 'كشف الدرجات والغيابات الفردي للطالب'}
                {reportType === 'section' && `كشف درجات مادة التربية الفنية - شعبة (${selectedSection?.name || 'أ'})`}
                {reportType === 'class' && `كشف الدرجات والنتائج العام - ${selectedClass?.name || ''}`}
                {reportType === 'annual_teacher' && `التقرير السنوي الشامل لمدرس المادة`}
              </h3>
              <p className="text-xs font-bold text-slate-600">
                العام الدراسي: {profile.academicYear}
              </p>
            </div>

            {/* Left: Teacher & Date */}
            <div className="space-y-0.5 text-left">
              <p className="text-xs font-bold">مدرس المادة: {profile.teacherName}</p>
              <p className="text-xs text-slate-700">الصف: {selectedClass?.name || '---'}</p>
              <p className="text-xs text-slate-700">الشعبة: ({selectedSection?.name || '---'})</p>
              <p className="text-[11px] text-slate-500 font-mono">{formatShortDate(new Date())}</p>
            </div>
          </div>
        </div>

        {/* ===================== REPORT A: INDIVIDUAL STUDENT REPORT ===================== */}
        {reportType === 'individual' && activeStudent && (
          <div className="space-y-6 text-xs text-slate-900">
            {/* Student Info Card */}
            {(() => {
              const allComp = getAllStudentCompliances(activeStudent.id);
              const commit = getCommitmentInfo(allComp);

              return (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-300 grid grid-cols-2 sm:grid-cols-5 gap-3 font-semibold">
                  <div>
                    <span className="text-slate-500 block text-[11px]">اسم الطالب:</span>
                    <span className="font-black text-sm text-slate-900">{activeStudent.fullName}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">الرقم الإحصائي:</span>
                    <span className="font-mono text-slate-900">{activeStudent.studentNumber}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">الصف والشعبة:</span>
                    <span>{selectedClass?.name} - ({selectedSection?.name})</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">حالة القيد:</span>
                    <span className="font-bold text-emerald-800">{activeStudent.status}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">حالة الالتزام:</span>
                    <span className="font-black text-slate-900 flex items-center gap-1">
                      <span
                        className={`w-2 h-2 rounded-full inline-block ${
                          commit.level === 'green'
                            ? 'bg-emerald-600'
                            : commit.level === 'yellow'
                            ? 'bg-amber-500'
                            : commit.level === 'orange'
                            ? 'bg-orange-500'
                            : 'bg-rose-600'
                        }`}
                      />
                      <span>{commit.label}</span>
                    </span>
                  </div>
                </div>
              );
            })()}

            {/* Detailed Grades Breakdown Table */}
            {(() => {
              const g = getStudentGrade(activeStudent.id);
              const att = getStudentAttendanceStats(activeStudent.id);

              return (
                <div className="space-y-4">
                  <h4 className="font-bold text-sm border-b border-slate-300 pb-1">
                    سجل الدرجات الفصلي والسنوي (مادة التربية الفنية):
                  </h4>

                  <table className="w-full text-center text-xs border border-slate-900 border-collapse">
                    <thead>
                      <tr className="bg-slate-100 font-bold border-b border-slate-900">
                        <th className="py-2 px-2 border-l border-slate-900">الفترة / الامتحان</th>
                        <th className="py-2 px-2 border-l border-slate-900">الشفهي</th>
                        <th className="py-2 px-2 border-l border-slate-900">التحريري</th>
                        <th className="py-2 px-2 border-l border-slate-900">المعدل الشهري</th>
                        <th className="py-2 px-2 border-l border-slate-900">السعي الفصلي</th>
                        <th className="py-2 px-2">ملاحظات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      <tr>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">شهر تشرين الأول (شهر 1)</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.oralM1 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.examM1 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">{g.avgM1 ?? '-'}</td>
                        <td rowSpan={2} className="py-2 px-2 border-l border-slate-900 font-black bg-slate-50 align-middle">
                          سعي ف1: {g.sem1Pursuit ?? '-'}
                        </td>
                        <td className="py-2 px-2 text-[11px] text-slate-600">الفصل الأول</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">شهر تشرين الثاني (شهر 2)</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.oralM2 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.examM2 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">{g.avgM2 ?? '-'}</td>
                        <td className="py-2 px-2 text-[11px] text-slate-600">الفصل الأول</td>
                      </tr>
                      <tr className="bg-slate-100 font-bold">
                        <td className="py-2 px-2 border-l border-slate-900">امتحان نصف السنة</td>
                        <td colSpan={3} className="py-2 px-2 border-l border-slate-900 font-black text-sm">
                          {g.midYearExam ?? 'بانتظار الرصد'}
                        </td>
                        <td className="py-2 px-2 border-l border-slate-900 font-black">{g.midYearExam ?? '-'}</td>
                        <td className="py-2 px-2 text-[11px]">امتحان نصف السنة العام</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">شهر شباط (شهر 1 - ف2)</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.oralM3 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.examM3 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">{g.avgM3 ?? '-'}</td>
                        <td rowSpan={2} className="py-2 px-2 border-l border-slate-900 font-black bg-slate-50 align-middle">
                          سعي ف2: {g.sem2Pursuit ?? '-'}
                        </td>
                        <td className="py-2 px-2 text-[11px] text-slate-600">الفصل الثاني</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">شهر آذار (شهر 2 - ف2)</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.oralM4 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900">{g.examM4 ?? '-'}</td>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">{g.avgM4 ?? '-'}</td>
                        <td className="py-2 px-2 text-[11px] text-slate-600">الفصل الثاني</td>
                      </tr>
                      <tr className="bg-slate-100 font-black">
                        <td className="py-2 px-2 border-l border-slate-900">السعي السنوي العام</td>
                        <td colSpan={3} className="py-2 px-2 border-l border-slate-900 text-slate-700 font-medium">
                          (سعي ف1 + سعي ف2 + نصف السنة) ÷ 3
                        </td>
                        <td className="py-2 px-2 border-l border-slate-900 text-sm font-black text-slate-900">
                          {g.annualPursuit ?? '-'}
                        </td>
                        <td className="py-2 px-2 text-[11px]">
                          {g.annualPursuit !== null ? 'معتمد لدخول النهائي' : 'قيد الاكتمال'}
                        </td>
                      </tr>
                      <tr>
                        <td className="py-2 px-2 border-l border-slate-900 font-bold">الامتحان النهائي (الدور الأول)</td>
                        <td colSpan={3} className="py-2 px-2 border-l border-slate-900">
                          درجة الامتحان النهائي من 100
                        </td>
                        <td className="py-2 px-2 border-l border-slate-900 font-black text-sm">
                          {g.finalExam ?? '-'}
                        </td>
                        <td className="py-2 px-2 text-[11px]">الامتحان النهائي</td>
                      </tr>
                      <tr className="bg-slate-200 font-black text-sm">
                        <td className="py-2.5 px-2 border-l border-slate-900">الدرجة النهائية والنتيجة</td>
                        <td colSpan={3} className="py-2 px-2 border-l border-slate-900">
                          (السعي السنوي + النهائي) ÷ 2
                        </td>
                        <td className="py-2.5 px-2 border-l border-slate-900 font-black text-base text-slate-950">
                          {g.finalGrade ?? '-'}
                        </td>
                        <td className="py-2.5 px-2 font-black text-emerald-800">
                          {g.resultStatus}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Attendance Summary */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-300 flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">ملخص المواظبة والغيابات:</span>
                    <span>مجموع الغياب بدون عذر: <b>{att.totalAbsences} يوم</b></span>
                    <span>الإجازات الرسمية: <b>{att.excused} يوم</b></span>
                    <span>التأخر الصباحي: <b>{att.late} مرة</b></span>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* ===================== REPORT B: COMPLETE SECTION REPORT ===================== */}
        {(reportType === 'section' || reportType === 'class' || reportType === 'annual_teacher') && (
          <div className="space-y-4 text-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-center text-[10px] border border-slate-900 border-collapse">
                <thead>
                  <tr className="bg-slate-100 font-bold border-b border-slate-900">
                    <th className="py-2 px-1 border-l border-slate-900 w-7">ت</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-mono w-14">الرقم</th>
                    <th className="py-2 px-2 border-l border-slate-900 text-right min-w-[130px]">
                      اسم الطالب الرباعي
                    </th>
                    <th className="py-2 px-1 border-l border-slate-900 min-w-[65px]">الالتزام</th>
                    <th className="py-2 px-1 border-l border-slate-900">شفهي1</th>
                    <th className="py-2 px-1 border-l border-slate-900">تحريري1</th>
                    <th className="py-2 px-1 border-l border-slate-900 bg-slate-50 font-bold">معدل1</th>
                    <th className="py-2 px-1 border-l border-slate-900">شفهي2</th>
                    <th className="py-2 px-1 border-l border-slate-900">تحريري2</th>
                    <th className="py-2 px-1 border-l border-slate-900 bg-slate-50 font-bold">معدل2</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-black bg-slate-100">سعي ف1</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-black bg-slate-200">نصف السنة</th>
                    <th className="py-2 px-1 border-l border-slate-900">شفهي3</th>
                    <th className="py-2 px-1 border-l border-slate-900">تحريري3</th>
                    <th className="py-2 px-1 border-l border-slate-900 bg-slate-50 font-bold">معدل3</th>
                    <th className="py-2 px-1 border-l border-slate-900">شفهي4</th>
                    <th className="py-2 px-1 border-l border-slate-900">تحريري4</th>
                    <th className="py-2 px-1 border-l border-slate-900 bg-slate-50 font-bold">معدل4</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-black bg-slate-100">سعي ف2</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-black bg-slate-200">السعي السنوي</th>
                    <th className="py-2 px-1 border-l border-slate-900">النهائي</th>
                    <th className="py-2 px-1 border-l border-slate-900 font-black text-[11px] bg-slate-100">
                      الدرجة
                    </th>
                    <th className="py-2 px-1 border-l border-slate-900 font-bold">النتيجة</th>
                    <th className="py-2 px-1">الغياب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300">
                  {sectionStudents.map((std, idx) => {
                    const g = getStudentGrade(std.id);
                    const att = getStudentAttendanceStats(std.id);
                    const allComp = getAllStudentCompliances(std.id);
                    const commit = getCommitmentInfo(allComp);

                    return (
                      <tr key={std.id} className="hover:bg-slate-50">
                        <td className="py-1.5 px-1 border-l border-slate-900">{idx + 1}</td>
                        <td className="py-1.5 px-1 border-l border-slate-900 font-mono text-[9px]">
                          {std.studentNumber}
                        </td>
                        <td className="py-1.5 px-2 border-l border-slate-900 text-right font-bold truncate max-w-[130px]">
                          {std.fullName}
                        </td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold text-[9px]">
                          <span
                            className={
                              commit.level === 'green'
                                ? 'text-emerald-700'
                                : commit.level === 'yellow'
                                ? 'text-amber-700'
                                : commit.level === 'orange'
                                ? 'text-orange-700'
                                : 'text-rose-700 font-black'
                            }
                          >
                            {commit.level === 'green' ? 'ملتزم' : `خصم -${commit.totalDeduction}`}
                          </span>
                        </td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.oralM1 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.examM1 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold bg-slate-50">{g.avgM1 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.oralM2 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.examM2 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold bg-slate-50">{g.avgM2 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-black bg-slate-100">{g.sem1Pursuit ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-black bg-slate-200">{g.midYearExam ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.oralM3 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.examM3 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold bg-slate-50">{g.avgM3 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.oralM4 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.examM4 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold bg-slate-50">{g.avgM4 ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-black bg-slate-100">{g.sem2Pursuit ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-black bg-slate-200">{g.annualPursuit ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900">{g.finalExam ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-black text-xs bg-slate-100">{g.finalGrade ?? '-'}</td>
                        <td className="py-1 px-1 border-l border-slate-900 font-bold">
                          <span
                            className={
                              g.resultStatus === 'ناجح'
                                ? 'text-emerald-800'
                                : g.resultStatus === 'مكمل'
                                ? 'text-rose-800'
                                : 'text-slate-600'
                            }
                          >
                            {g.resultStatus}
                          </span>
                        </td>
                        <td className="py-1 px-1 font-bold">{att.totalAbsences}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Signatures & Seal Lines */}
        <div className="mt-12 pt-6 grid grid-cols-3 gap-6 text-center text-xs font-bold text-slate-900">
          <div className="space-y-6">
            <p>مدرس المادة: {profile.teacherName}</p>
            <p className="border-t border-dotted border-slate-400 pt-1">التوقيع والتاريخ</p>
          </div>

          <div className="space-y-6">
            <p>معاون شؤون الطلبة</p>
            <p className="border-t border-dotted border-slate-400 pt-1">التوقيع والتاريخ</p>
          </div>

          <div className="space-y-6">
            <p>مدير ثانوية الديوانية للمتميزين والختم</p>
            <p className="border-t border-dotted border-slate-400 pt-1">التوقيع والختم الرسمي</p>
          </div>
        </div>
      </div>
    </div>
  );
};
