import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Layers,
  Users,
  Search,
  Filter,
  Info,
  Clock,
  RotateCcw,
  Plus,
  Edit2,
  Trash2,
  X,
  Sparkles,
  ShieldAlert,
  ArrowLeft,
  ChevronDown,
  Check,
  Award,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import {
  Student,
  StudentMonthlyCompliance,
  CommitmentLevel,
  CommitmentInfo,
} from '../../types';
import { getCommitmentInfo } from '../../utils/gradingEngine';
import { getTodayDateString, formatIraqiDate, formatShortDate } from '../../utils/dateUtils';

const VIOLATION_REASONS_PRESETS = [
  'عدم إحضار كراس الرسم وألوان الحصة',
  'عدم إنجاز اللوحة المطلوبة في موعدها',
  'إهمال نظافة المرسم وأدوات العمل الفني',
  'التأخر المتكرر عن دخول حصة التربية الفنية',
  'مخالفة التعليمات والانشغال أثناء الدرس',
  'إتلاف أو سوء استخدام خامات ومستلزمات المرسم',
];

export const NonComplianceScreen: React.FC = () => {
  const {
    classes,
    sections,
    students,
    grades,
    compliances,
    toggleNonComplianceCheck,
    getStudentMonthlyCompliance,
    getAllStudentCompliances,
    selectedClassId,
    setSelectedClassId,
    selectedSectionId,
    setSelectedSectionId,
    setActiveScreen,
    profile,
  } = useTeacherApp();

  // Filters
  const [selectedMonth, setSelectedMonth] = useState<1 | 2 | 3 | 4>(1);
  const [statusFilter, setStatusFilter] = useState<'all' | 'compliant' | 'non_compliant' | 'critical'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Reason Modal
  const [modalStudentId, setModalStudentId] = useState<string | null>(null);
  const [modalMonthIndex, setModalMonthIndex] = useState<1 | 2 | 3 | 4>(1);
  const [modalCheckIndex, setModalCheckIndex] = useState<1 | 2 | 3 | 4>(1);
  const [modalReason, setModalReason] = useState('');
  const [modalDate, setModalDate] = useState(getTodayDateString());
  const [isReasonModalOpen, setIsReasonModalOpen] = useState(false);

  // Success Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const activeClasses = classes.filter((c) => !c.archived);
  const activeSections = sections.filter((s) => s.classId === selectedClassId && !s.archived);

  // Section Students
  const sectionStudents = useMemo(() => {
    return students.filter(
      (s) =>
        s.classId === selectedClassId &&
        s.sectionId === selectedSectionId &&
        !s.archived &&
        s.status === 'مستمر'
    );
  }, [students, selectedClassId, selectedSectionId]);

  // Enriched Students with compliance data
  const enrichedStudents = useMemo(() => {
    return sectionStudents.map((std) => {
      const allComp = getAllStudentCompliances(std.id);
      const commitment = getCommitmentInfo(allComp);
      const currentMonthComp = getStudentMonthlyCompliance(std.id, selectedMonth);
      const grade = grades[std.id];

      // Get monthly exam status:
      // Month 1 -> rawExamM1 / examM1
      // Month 2 -> rawExamM2 / examM2
      // Month 3 -> rawExamM3 / examM3
      // Month 4 -> rawExamM4 / examM4
      let rawExam: number | null = null;
      let netExam: number | null = null;

      if (selectedMonth === 1) {
        rawExam = grade?.rawExamM1 ?? grade?.examM1 ?? null;
        netExam = grade?.examM1 ?? null;
      } else if (selectedMonth === 2) {
        rawExam = grade?.rawExamM2 ?? grade?.examM2 ?? null;
        netExam = grade?.examM2 ?? null;
      } else if (selectedMonth === 3) {
        rawExam = grade?.rawExamM3 ?? grade?.examM3 ?? null;
        netExam = grade?.examM3 ?? null;
      } else if (selectedMonth === 4) {
        rawExam = grade?.rawExamM4 ?? grade?.examM4 ?? null;
        netExam = grade?.examM4 ?? null;
      }

      return {
        student: std,
        commitment,
        currentMonthComp,
        rawExam,
        netExam,
        hasGradeEntered: rawExam !== null,
      };
    });
  }, [sectionStudents, getAllStudentCompliances, getStudentMonthlyCompliance, selectedMonth, grades]);

  // Filtered list
  const filteredStudents = useMemo(() => {
    return enrichedStudents.filter((item) => {
      // Status filter
      if (statusFilter === 'compliant' && item.commitment.totalInfractions > 0) return false;
      if (statusFilter === 'non_compliant' && item.commitment.totalInfractions === 0) return false;
      if (statusFilter === 'critical' && item.commitment.level !== 'dark_red' && item.commitment.level !== 'red') return false;

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.student.fullName.toLowerCase().includes(q);
        const matchNum = item.student.studentNumber.toLowerCase().includes(q);
        if (!matchName && !matchNum) return false;
      }

      return true;
    });
  }, [enrichedStudents, statusFilter, searchQuery]);

  // Statistics for current selection
  const stats = useMemo(() => {
    let compliantCount = 0;
    let warningCount = 0;
    let repeatedCount = 0;
    let criticalCount = 0;
    let totalDeductionsInMonth = 0;

    enrichedStudents.forEach((item) => {
      if (item.commitment.level === 'green') compliantCount++;
      else if (item.commitment.level === 'yellow') warningCount++;
      else if (item.commitment.level === 'orange' || item.commitment.level === 'red') repeatedCount++;
      else if (item.commitment.level === 'dark_red') criticalCount++;

      totalDeductionsInMonth += item.currentMonthComp.totalDeduction;
    });

    return {
      total: enrichedStudents.length,
      compliantCount,
      warningCount,
      repeatedCount,
      criticalCount,
      totalDeductionsInMonth,
    };
  }, [enrichedStudents]);

  const monthLabels: Record<1 | 2 | 3 | 4, { name: string; term: string }> = {
    1: { name: 'شهر تشرين الأول (شهر 1)', term: 'الفصل الدراسي الأول' },
    2: { name: 'شهر تشرين الثاني (شهر 2)', term: 'الفصل الدراسي الأول' },
    3: { name: 'شهر شباط (شهر 1)', term: 'الفصل الدراسي الثاني' },
    4: { name: 'شهر آذار (شهر 2)', term: 'الفصل الدراسي الثاني' },
  };

  // Open modal to add/edit check with reason
  const handleOpenCheckModal = (
    studentId: string,
    monthIdx: 1 | 2 | 3 | 4,
    checkIdx: 1 | 2 | 3 | 4,
    existingReason?: string,
    existingDate?: string
  ) => {
    setModalStudentId(studentId);
    setModalMonthIndex(monthIdx);
    setModalCheckIndex(checkIdx);
    setModalReason(existingReason || VIOLATION_REASONS_PRESETS[0]);
    setModalDate(existingDate || getTodayDateString());
    setIsReasonModalOpen(true);
  };

  const handleSaveModalCheck = () => {
    if (!modalStudentId) return;

    toggleNonComplianceCheck(
      modalStudentId,
      modalMonthIndex,
      modalCheckIndex,
      true,
      modalReason,
      modalDate
    );

    setIsReasonModalOpen(false);
    setToastMessage('تم تسجيل المتابعة وخصم 5 درجات بنجاح، وإعادة حساب الدرجة لحظياً.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Direct toggle (when unchecking to clear)
  const handleToggleCheckDirect = (
    studentId: string,
    monthIdx: 1 | 2 | 3 | 4,
    checkIdx: 1 | 2 | 3 | 4,
    currentVal: boolean
  ) => {
    if (currentVal) {
      // Unchecking (Canceling check)
      toggleNonComplianceCheck(studentId, monthIdx, checkIdx, false);
      setToastMessage('تم إلغاء المتابعة واسترجاع 5 درجات للدرجة الشهرية تلقائياً.');
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      // Checking -> Open reason modal for clean recording
      handleOpenCheckModal(studentId, monthIdx, checkIdx);
    }
  };

  // Reset all 4 checks for a student in this month
  const handleResetMonthChecks = (studentId: string) => {
    [1, 2, 3, 4].forEach((idx) => {
      toggleNonComplianceCheck(studentId, selectedMonth, idx as 1 | 2 | 3 | 4, false);
    });
    setToastMessage('تم تصفير وإلغاء جميع خصومات هذا الشهر للطالب بنجاح.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-28">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 p-4 rounded-2xl bg-teal-600 text-white font-bold text-xs shadow-2xl border border-teal-400/40 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-white shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/15 text-rose-300 text-xs font-bold border border-rose-500/30 mb-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>نظام ضبط ومتابعة الالتزام المدرسي</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>قسم غير الملتزم (متابعة الالتزام والانضباط)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            متابعة دقيقة مستقلة للالتزام لجميع الصفوف والشعب (4 مرات شهرياً • 5 درجات لكل مرة • حد أقصى 20 درجة شهرياً).
            الخصم يمس الدرجة الشهرية فقط ولا يؤثر نهائياً على الشفهي أو نصف السنة أو الامتحان النهائي.
          </p>
        </div>

        <button
          onClick={() => setActiveScreen('gradebook_attendance')}
          className="px-4 py-2.5 rounded-2xl bg-[#161F30] hover:bg-[#1E2B42] border border-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center gap-2 shadow-sm cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-sky-400" />
          <span>الذهاب إلى سجل الدرجات</span>
        </button>
      </div>

      {/* Rules & Transparency Alert Box */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-rose-950/40 via-[#181E2B] to-[#161F30] border border-rose-800/40 text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 text-rose-300 font-black text-sm">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>ضوابط وقواعد خصم عدم الالتزام المعتمدة:</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1 text-[11px]">
          <div className="flex items-start gap-1.5 bg-black/20 p-2 rounded-xl border border-slate-800">
            <Check className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
            <span><b>4 متابعات شهرياً:</b> يُخصم 5 درجات عن كل متابعة غير ملتزمة حتى 20 درجة كحد أقصى.</span>
          </div>
          <div className="flex items-start gap-1.5 bg-black/20 p-2 rounded-xl border border-slate-800">
            <Check className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
            <span><b>خصم مستحق:</b> إذا لم تُدخل الدرجة بعد، يُحفظ الخصم كخصم مستحق ويُطبّق فور رصد الامتحان.</span>
          </div>
          <div className="flex items-start gap-1.5 bg-black/20 p-2 rounded-xl border border-slate-800">
            <Check className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
            <span><b>حماية الدرجة:</b> لا يمس الشفهي أو نصف السنة أو النهائي، والدرجة لا تقل عن صفر.</span>
          </div>
        </div>
      </div>

      {/* Selectors Bar: Class, Section, and Month */}
      <div className="p-4 rounded-3xl bg-[#161F30] border border-slate-800 shadow-md space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Class */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الصف الدراسي</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                const firstSec = sections.find((s) => s.classId === e.target.value);
                if (firstSec) setSelectedSectionId(firstSec.id);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeClasses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشعبة</label>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-bold focus:outline-hidden"
            >
              {activeSections.map((sec) => (
                <option key={sec.id} value={sec.id}>
                  شعبة {sec.name}
                </option>
              ))}
            </select>
          </div>

          {/* Month Selector */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 mb-1">الشهر المستهدف للمتابعة</label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value) as 1 | 2 | 3 | 4)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-rose-500/50 text-rose-300 font-bold focus:outline-hidden"
            >
              <option value={1}>شهر 1 ف1 (تشرين الأول) - 4 متابعات</option>
              <option value={2}>شهر 2 ف1 (تشرين الثاني) - 4 متابعات</option>
              <option value={3}>شهر 1 ف2 (شباط) - 4 متابعات</option>
              <option value={4}>شهر 2 ف2 (آذار) - 4 متابعات</option>
            </select>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Status Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
            <span className="text-[11px] text-slate-400 font-bold ml-1">تصفية:</span>
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-[#0D131F] text-slate-400 hover:text-white'
              }`}
            >
              الكل ({stats.total})
            </button>
            <button
              onClick={() => setStatusFilter('compliant')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                statusFilter === 'compliant'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-[#0D131F] text-emerald-400 hover:bg-emerald-950/30'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
              <span>الملتزمون ({stats.compliantCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('non_compliant')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                statusFilter === 'non_compliant'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-[#0D131F] text-amber-400 hover:bg-amber-950/30'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
              <span>تنبيهات وخصومات ({stats.warningCount + stats.repeatedCount + stats.criticalCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('critical')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                statusFilter === 'critical'
                  ? 'bg-rose-700 text-white shadow-xs'
                  : 'bg-[#0D131F] text-rose-400 hover:bg-rose-950/30'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
              <span>حالات حرجة ({stats.criticalCount})</span>
            </button>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث بالاسم أو الرقم..."
              className="w-full pr-9 pl-3 py-1.5 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Summary Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-[#161F30] border border-emerald-500/20">
          <div className="flex items-center justify-between text-emerald-400 mb-1">
            <span className="text-[11px] font-bold">طالب ملتزم وجيد</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
          </div>
          <div className="text-xl font-black text-emerald-300">{stats.compliantCount}</div>
          <span className="text-[10px] text-slate-400 block mt-0.5">درجة كاملة دون خصومات</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#161F30] border border-amber-500/20">
          <div className="flex items-center justify-between text-amber-400 mb-1">
            <span className="text-[11px] font-bold">تنبيه أولي (5 درجات)</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-300">{stats.warningCount}</div>
          <span className="text-[10px] text-slate-400 block mt-0.5">مخالفة واحدة مسجلة</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#161F30] border border-orange-500/20">
          <div className="flex items-center justify-between text-orange-400 mb-1">
            <span className="text-[11px] font-bold">تكرار عدم الالتزام</span>
            <span className="w-2.5 h-2.5 rounded-full bg-orange-400" />
          </div>
          <div className="text-xl font-black text-orange-300">{stats.repeatedCount}</div>
          <span className="text-[10px] text-slate-400 block mt-0.5">خصم 10 أو 15 درجة</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#161F30] border border-rose-500/30">
          <div className="flex items-center justify-between text-rose-400 mb-1">
            <span className="text-[11px] font-bold">إجمالي درجات الخصم</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-black text-rose-400">-{stats.totalDeductionsInMonth} درجة</div>
          <span className="text-[10px] text-slate-400 block mt-0.5">في {monthLabels[selectedMonth].name}</span>
        </div>
      </div>

      {/* Main Students List */}
      <div className="space-y-3">
        {filteredStudents.length === 0 ? (
          <div className="p-12 text-center bg-[#161F30] rounded-3xl border border-slate-800 space-y-2">
            <ShieldAlert className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-sm font-bold text-slate-300">لا يوجد طلبة مطابقين لمعايير البحث والتصفية</h4>
            <p className="text-xs text-slate-500">اختر شعبة أخرى أو غيّر حالة التصفية</p>
          </div>
        ) : (
          filteredStudents.map((item) => {
            const { student, commitment, currentMonthComp, rawExam, netExam, hasGradeEntered } = item;
            const currentDeduction = currentMonthComp.totalDeduction;

            return (
              <div
                key={student.id}
                className={`p-4 sm:p-5 rounded-3xl bg-[#161F30] border transition-all ${
                  commitment.level === 'dark_red'
                    ? 'border-rose-700 bg-rose-950/20'
                    : commitment.level === 'red'
                    ? 'border-rose-500/40 bg-rose-950/10'
                    : commitment.level === 'orange'
                    ? 'border-orange-500/30'
                    : commitment.level === 'yellow'
                    ? 'border-amber-500/30'
                    : 'border-slate-800'
                }`}
              >
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                  {/* Student Identity and Commitment Color Badge */}
                  <div className="space-y-1.5 w-full lg:w-1/3">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm sm:text-base text-white">
                        {student.fullName}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-md">
                        {student.studentNumber}
                      </span>
                    </div>

                    {/* Graded Color Status Badge */}
                    <div className="flex items-center gap-2">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold border ${commitment.bgClass} ${commitment.colorClass} ${commitment.borderClass}`}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${
                            commitment.level === 'green'
                              ? 'bg-emerald-400'
                              : commitment.level === 'yellow'
                              ? 'bg-amber-400'
                              : commitment.level === 'orange'
                              ? 'bg-orange-400'
                              : commitment.level === 'red'
                              ? 'bg-rose-500'
                              : 'bg-rose-300 animate-pulse'
                          }`}
                        />
                        <span>{commitment.label}</span>
                      </span>

                      {currentDeduction > 0 && (
                        <button
                          onClick={() => handleResetMonthChecks(student.id)}
                          title="إلغاء جميع خصومات هذا الشهر"
                          className="text-[11px] text-slate-400 hover:text-rose-300 underline cursor-pointer"
                        >
                          تصفير الشهر
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 4 Independent Follow-up Checks for Current Month */}
                  <div className="flex-1 w-full bg-[#0D131F] p-3 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold border-b border-slate-800/80 pb-1.5">
                      <span className="text-slate-300 font-black">
                        متابعات {monthLabels[selectedMonth].name}:
                      </span>
                      <span
                        className={`font-black ${
                          currentDeduction > 0 ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        {currentDeduction > 0 ? `إجمالي الخصم: -${currentDeduction} درجة` : 'ملتزم تماماً (خصم: 0)'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {currentMonthComp.checks.map((chk) => {
                        const isChecked = chk.isNonCompliant;

                        return (
                          <div
                            key={chk.checkIndex}
                            className={`p-2 rounded-xl border transition-all ${
                              isChecked
                                ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                                : 'bg-[#161F30] border-slate-700/80 text-slate-400 hover:border-slate-600'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-[11px] font-bold">
                                المتابعة {chk.checkIndex}
                              </span>
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() =>
                                  handleToggleCheckDirect(
                                    student.id,
                                    selectedMonth,
                                    chk.checkIndex,
                                    isChecked
                                  )
                                }
                                className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 border-slate-700 cursor-pointer"
                              />
                            </div>

                            {isChecked ? (
                              <div className="space-y-1">
                                <div className="text-[10px] font-black text-rose-400 flex items-center justify-between">
                                  <span>خصم -5 درجات</span>
                                  <button
                                    onClick={() =>
                                      handleOpenCheckModal(
                                        student.id,
                                        selectedMonth,
                                        chk.checkIndex,
                                        chk.reason,
                                        chk.date
                                      )
                                    }
                                    title="تعديل السبب والتاريخ"
                                    className="text-slate-300 hover:text-white"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                </div>
                                <div className="text-[10px] text-slate-300 truncate" title={chk.reason}>
                                  {chk.reason || 'مخالفة غير محددة'}
                                </div>
                                <div className="text-[9px] text-slate-400">
                                  {chk.date ? formatShortDate(chk.date) : ''}
                                </div>
                              </div>
                            ) : (
                              <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                                <Check className="w-3 h-3 text-emerald-500" />
                                <span>ملتزم (0 خصم)</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Impact on Monthly Grade (Applied vs Pending Due) */}
                  <div className="w-full lg:w-48 bg-[#0D131F] p-3 rounded-2xl border border-slate-800 text-right space-y-1">
                    <span className="block text-[10px] font-bold text-slate-400">
                      حالة الدرجة الشهرية
                    </span>

                    {hasGradeEntered ? (
                      <div>
                        <div className="text-xs text-slate-300">
                          الدرجة الأصلية: <b className="text-white">{rawExam}</b>
                        </div>
                        {currentDeduction > 0 ? (
                          <>
                            <div className="text-xs text-rose-400 font-bold">
                              الخصم المطبق: -{currentDeduction}
                            </div>
                            <div className="text-sm font-black text-teal-300 pt-1 border-t border-slate-800">
                              الصافي: {netExam}
                            </div>
                          </>
                        ) : (
                          <div className="text-xs text-emerald-400 font-bold mt-1">
                            لا يوجد خصم مطبق ({netExam})
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="py-1">
                        {currentDeduction > 0 ? (
                          <div className="space-y-0.5">
                            <span className="inline-block text-[10px] font-black px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              خصم مستحق: -{currentDeduction}
                            </span>
                            <p className="text-[10px] text-slate-400 leading-tight">
                              سيُطبّق تلقائياً فور رصد درجة الامتحان
                            </p>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-500 block">
                            بانتظار رصد الدرجة
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal for Recording Check Reason & Date */}
      {isReasonModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#161F30] border border-slate-700 w-full max-w-md rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-400" />
                <span>تسجيل متابعة عدم التزام (المتابعة {modalCheckIndex})</span>
              </h3>
              <button
                onClick={() => setIsReasonModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              سيتم تسجيل خصم <b>5 درجات</b> من الدرجة الشهرية للطالب فورياً وحفظ السبب والتاريخ في السجل.
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                تاريخ حدوث المخالفة
              </label>
              <input
                type="date"
                value={modalDate}
                onChange={(e) => setModalDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white font-mono focus:outline-hidden"
              />
            </div>

            {/* Presets */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                أسباب شائعة (اختر للتعبئة السريعة):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {VIOLATION_REASONS_PRESETS.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setModalReason(preset)}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-[#0D131F] hover:bg-slate-800 text-slate-300 border border-slate-700 cursor-pointer"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Reason Text */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                سبب عدم الالتزام بالتفصيل
              </label>
              <textarea
                rows={3}
                value={modalReason}
                onChange={(e) => setModalReason(e.target.value)}
                placeholder="اكتب سبب عدم الالتزام أو ملاحظتك للمعلم..."
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsReasonModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSaveModalCheck}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-lg cursor-pointer"
              >
                تأكيد وتسجيل الخصم (-5 درجات)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
