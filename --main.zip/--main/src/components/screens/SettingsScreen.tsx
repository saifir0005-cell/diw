import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Save,
  Download,
  Upload,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  School,
  User,
  Sliders,
  ShieldCheck,
  FileJson,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';

export const SettingsScreen: React.FC = () => {
  const {
    profile,
    updateProfile,
    gradingConfig,
    updateGradingConfig,
    exportFullBackupJSON,
    importFullBackupJSON,
    resetAppToDefaults,
    seedDemoTeacherData,
  } = useTeacherApp();

  // Profile Form
  const [teacherName, setTeacherName] = useState(profile.teacherName);
  const [schoolName, setSchoolName] = useState(profile.schoolName);
  const [subject, setSubject] = useState(profile.subject);
  const [academicYear, setAcademicYear] = useState(profile.academicYear);

  // Grading Config Form
  const [minPass, setMinPass] = useState(gradingConfig.minPassingGrade);
  const [rounding, setRounding] = useState(gradingConfig.roundingRule);
  const [ruleYear, setRuleYear] = useState(gradingConfig.academicYear);
  const [treatBlank, setTreatBlank] = useState(gradingConfig.treatBlankAsZero);

  // Status Alerts
  const [saveAlert, setSaveAlert] = useState(false);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      teacherName: teacherName.trim(),
      schoolName: schoolName.trim(),
      subject: subject.trim(),
      academicYear: academicYear.trim(),
    });
    updateGradingConfig({
      academicYear: ruleYear,
      minPassingGrade: Number(minPass),
      roundingRule: rounding,
      treatBlankAsZero: treatBlank,
    });
    setSaveAlert(true);
    setTimeout(() => setSaveAlert(false), 2500);
  };

  const handleDownloadBackup = () => {
    const json = exportFullBackupJSON();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(json);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `نسخة_احتياطية_سجلي_المدرسي_${teacherName.replace(/\s+/g, '_')}_${academicYear}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setBackupMessage('تم تنزيل النسخة الاحتياطية بنجاح.');
    setTimeout(() => setBackupMessage(null), 3000);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = importFullBackupJSON(content);
      if (res.success) {
        setBackupMessage('تمت استعادة النسخة الاحتياطية بنجاح.');
      } else {
        alert(res.message);
      }
      setTimeout(() => setBackupMessage(null), 3000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-28">
      {/* Top Header */}
      <div>
        <h2 className="text-xl font-black text-white flex items-center gap-2">
          <SettingsIcon className="w-6 h-6 text-sky-400" />
          <span>إعدادات التطبيق والملف الشخصي</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          تعديل اسم الأستاذ، المدرسة، العام الدراسي، وقواعد احتساب الدرجات
        </p>
      </div>

      {saveAlert && (
        <div className="p-3.5 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span>تم حفظ الإعدادات بنجاح.</span>
        </div>
      )}

      {backupMessage && (
        <div className="p-3.5 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-sky-400" />
          <span>{backupMessage}</span>
        </div>
      )}

      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Profile Card */}
        <div className="p-5 rounded-3xl bg-[#161F30] border border-slate-800 space-y-4 shadow-md">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <User className="w-5 h-5 text-sky-400" />
            <h3 className="font-extrabold text-sm text-white">بيانات الأستاذ والمدرسة</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسم الأستاذ</label>
              <input
                type="text"
                required
                value={teacherName}
                onChange={(e) => setTeacherName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-sky-400 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">المدرسة</label>
              <input
                type="text"
                required
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-sky-400 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">المادة</label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-sky-400 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">العام الدراسي</label>
              <input
                type="text"
                required
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-sky-400 focus:outline-hidden font-bold text-sky-400"
              />
            </div>
          </div>
        </div>

        {/* Grading Engine Configuration Card */}
        <div className="p-5 rounded-3xl bg-[#161F30] border border-slate-800 space-y-4 shadow-md">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <h3 className="font-extrabold text-sm text-white">محرك قواعد التقييم والدرجات</h3>
            </div>
            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-teal-500/15 text-teal-300 border border-teal-500/30">
              قواعد معتمدة لوزارة التربية العراقية
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                نظام قواعد العام الدراسي
              </label>
              <select
                value={ruleYear}
                onChange={(e) => setRuleYear(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden font-bold"
              >
                <option value="2026–2027">قواعد العام 2026–2027</option>
                <option value="2025–2026">قواعد العام 2025–2026</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                الدرجة الصغرى للنجاح (من 100)
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={minPass}
                onChange={(e) => setMinPass(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                قاعدة جبر وجبر الكسور (التقريب)
              </label>
              <select
                value={rounding}
                onChange={(e) => setRounding(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-[#0D131F] border border-slate-700 text-white focus:outline-hidden"
              >
                <option value="standard">تقريب قياسي (أقرب عدد صحيح)</option>
                <option value="floor">حذف الكسر (Floor)</option>
                <option value="ceil">جبر الكسر دائماً لصالح الطالب (Ceil)</option>
              </select>
            </div>
          </div>

          {/* Toggle treat blank as zero */}
          <div className="pt-2 flex items-center justify-between text-xs text-slate-300 bg-[#0D131F] p-3 rounded-2xl border border-slate-800">
            <div>
              <span className="font-bold text-white block">
                معاملة الحقول الفارغة (عدم التحويل لصفر تلقائياً)
              </span>
              <span className="text-[11px] text-slate-400">
                النظام لا يعتبر الحقل الفارغ صفراً حتى لا يؤثر ظلماً على معدل الطالب أثناء الفصل
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={treatBlank}
                onChange={(e) => setTreatBlank(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
            </label>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-lg shadow-sky-950/40 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>
        </div>
      </form>

      {/* Backup and Restore Section */}
      <div className="p-5 rounded-3xl bg-[#161F30] border border-slate-800 space-y-4 shadow-md">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <FileJson className="w-5 h-5 text-indigo-400" />
          <h3 className="font-extrabold text-sm text-white">النسخ الاحتياطي والاستعادة المحلية</h3>
        </div>

        <p className="text-xs text-slate-400">
          التطبيق يعمل محلياً دون الحاجة لاتصال بالإنترنت (Offline-First). يمكنك تنزيل نسخة احتياطية كاملة واسترجاعها بأي وقت.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={handleDownloadBackup}
            className="p-3.5 rounded-2xl bg-[#0D131F] hover:bg-[#111927] border border-slate-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>تصدير نسخة احتياطية (JSON)</span>
          </button>

          <label className="p-3.5 rounded-2xl bg-[#0D131F] hover:bg-[#111927] border border-slate-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4 text-teal-400" />
            <span>استعادة نسخة من ملف</span>
            <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
          </label>

          <button
            onClick={seedDemoTeacherData}
            className="p-3.5 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>تحميل بيانات نموذجية للتجربة</span>
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="p-5 rounded-3xl bg-rose-950/20 border border-rose-900/40 flex items-center justify-between gap-4">
        <div>
          <h4 className="font-extrabold text-xs text-rose-300">إعادة ضبط التطبيق ومسح السجلات</h4>
          <p className="text-[11px] text-slate-400 mt-0.5">
            حذف كافة الصفوف والطلبة والدرجات المخزنة على هذا الهاتف.
          </p>
        </div>

        {confirmReset ? (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setConfirmReset(false)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
            >
              إلغاء
            </button>
            <button
              onClick={() => {
                resetAppToDefaults();
                setConfirmReset(false);
              }}
              className="px-4 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold"
            >
              تأكيد المسح
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="px-4 py-2 rounded-xl bg-rose-600/30 hover:bg-rose-600 text-rose-200 hover:text-white border border-rose-500/40 text-xs font-bold cursor-pointer transition-all"
          >
            مسح البيانات
          </button>
        )}
      </div>
    </div>
  );
};
