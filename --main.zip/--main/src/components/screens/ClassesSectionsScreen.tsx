import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Edit2,
  Archive,
  Trash2,
  Users,
  Grid3X3,
  Palette,
  CalendarCheck2,
  ChevronLeft,
  X,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { useTeacherApp } from '../../context/TeacherAppContext';
import { ClassGrade, Section } from '../../types';

export const ClassesSectionsScreen: React.FC = () => {
  const {
    classes,
    addClass,
    updateClass,
    archiveClass,
    deleteClass,
    sections,
    addSection,
    updateSection,
    archiveSection,
    deleteSection,
    students,
    setSelectedClassId,
    setSelectedSectionId,
    setActiveScreen,
    seedDemoTeacherData,
  } = useTeacherApp();

  // Modals state
  const [isAddClassOpen, setIsAddClassOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassGrade | null>(null);
  const [newClassName, setNewClassName] = useState('');

  const [isAddSectionOpen, setIsAddSectionOpen] = useState(false);
  const [selectedClassForSection, setSelectedClassForSection] = useState<string>('');
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const [newSectionName, setNewSectionName] = useState('أ');

  const [confirmDelete, setConfirmDelete] = useState<{ type: 'class' | 'section'; id: string; name: string } | null>(null);

  const handleSaveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;

    if (editingClass) {
      updateClass(editingClass.id, newClassName);
    } else {
      addClass(newClassName);
    }
    setNewClassName('');
    setEditingClass(null);
    setIsAddClassOpen(false);
  };

  const handleSaveSection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSectionName.trim() || !selectedClassForSection) return;

    if (editingSection) {
      updateSection(editingSection.id, newSectionName);
    } else {
      addSection(selectedClassForSection, newSectionName);
    }
    setNewSectionName('أ');
    setEditingSection(null);
    setIsAddSectionOpen(false);
  };

  const openSectionGradebook = (classId: string, sectionId: string) => {
    setSelectedClassId(classId);
    setSelectedSectionId(sectionId);
    setActiveScreen('gradebook_attendance');
  };

  const openSectionStudents = (classId: string, sectionId: string) => {
    setSelectedClassId(classId);
    setSelectedSectionId(sectionId);
    setActiveScreen('student_register');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-24">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-teal-400" />
            <span>الصفوف والشعب الدراسية</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            إضافة المراحل والشعب التي تدرسها في مادة التربية الفنية
          </p>
        </div>

        <button
          onClick={() => {
            setEditingClass(null);
            setNewClassName('');
            setIsAddClassOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-lg shadow-teal-950/40 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة صف دراسي</span>
        </button>
      </div>

      {/* Empty State */}
      {classes.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-800 bg-[#141B2A] p-10 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center mx-auto">
            <Layers className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">لا توجد صفوف مضافة حالياً</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              ابدأ بإضافة الصفوف التي تدرسها يدوياً (مثل: الأول المتوسط، الثاني المتوسط)
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              onClick={() => {
                setEditingClass(null);
                setNewClassName('الأول المتوسط');
                setIsAddClassOpen(true);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
            >
              + إضافة الأول المتوسط
            </button>
            <button
              onClick={() => {
                setEditingClass(null);
                setNewClassName('الثاني المتوسط');
                setIsAddClassOpen(true);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
            >
              + إضافة الثاني المتوسط
            </button>
            <button
              onClick={seedDemoTeacherData}
              className="px-3.5 py-1.5 rounded-xl bg-teal-950/80 hover:bg-teal-900/80 text-teal-300 border border-teal-800/60 text-xs font-bold cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>تحميل بيانات نموذجية للتجربة</span>
            </button>
          </div>
        </div>
      ) : (
        /* Classes & Sections List */
        <div className="space-y-5">
          {classes.map((cls) => {
            const classSections = sections.filter((s) => s.classId === cls.id);
            const classStudents = students.filter((std) => std.classId === cls.id && !std.archived);

            return (
              <div
                key={cls.id}
                className={`rounded-3xl border bg-[#161F30] p-5 shadow-md transition-all ${
                  cls.archived ? 'opacity-60 border-slate-800' : 'border-slate-800/90 hover:border-slate-700'
                }`}
              >
                {/* Class Header */}
                <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-400 flex items-center justify-center font-black text-sm">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-base text-white">{cls.name}</h3>
                        {cls.archived && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                            مؤرشف
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-slate-400 font-medium">
                        {classSections.length} شعب • {classStudents.length} طالب
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setSelectedClassForSection(cls.id);
                        setEditingSection(null);
                        setNewSectionName('أ');
                        setIsAddSectionOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-teal-600/20 hover:bg-teal-600/30 text-teal-300 border border-teal-500/30 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة شعبة</span>
                    </button>

                    <button
                      onClick={() => {
                        setEditingClass(cls);
                        setNewClassName(cls.name);
                        setIsAddClassOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                      title="تعديل اسم الصف"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => archiveClass(cls.id)}
                      className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                      title={cls.archived ? 'إلغاء الأرشفة' : 'أرشفة الصف'}
                    >
                      <Archive className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() =>
                        setConfirmDelete({
                          type: 'class',
                          id: cls.id,
                          name: cls.name,
                        })
                      }
                      className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                      title="حذف الصف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Sections List in this Class */}
                <div className="pt-4">
                  {classSections.length === 0 ? (
                    <div className="text-center py-4 bg-[#111827]/60 rounded-2xl border border-slate-800/60">
                      <p className="text-xs text-slate-400">لا توجد شعب مضافة لهذا الصف بعد.</p>
                      <button
                        onClick={() => {
                          setSelectedClassForSection(cls.id);
                          setEditingSection(null);
                          setNewSectionName('أ');
                          setIsAddSectionOpen(true);
                        }}
                        className="mt-2 text-xs text-teal-400 font-bold hover:underline"
                      >
                        + أضف شعبة (أ) الآن
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {classSections.map((sec) => {
                        const secStudents = students.filter(
                          (std) => std.sectionId === sec.id && !std.archived
                        );

                        return (
                          <div
                            key={sec.id}
                            className={`p-3.5 rounded-2xl bg-[#111827] border flex flex-col justify-between transition-all ${
                              sec.archived ? 'border-slate-800 opacity-60' : 'border-slate-800/80 hover:border-slate-700'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="w-7 h-7 rounded-xl bg-teal-500/20 text-teal-300 font-black text-xs flex items-center justify-center">
                                  {sec.name}
                                </span>
                                <div>
                                  <span className="font-extrabold text-sm text-white">
                                    شعبة {sec.name}
                                  </span>
                                  <span className="block text-[11px] text-slate-400">
                                    {secStudents.length} طالب
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => {
                                    setSelectedClassForSection(cls.id);
                                    setEditingSection(sec);
                                    setNewSectionName(sec.name);
                                    setIsAddSectionOpen(true);
                                  }}
                                  className="p-1 text-slate-400 hover:text-white"
                                  title="تعديل اسم الشعبة"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() =>
                                    setConfirmDelete({
                                      type: 'section',
                                      id: sec.id,
                                      name: `شعبة ${sec.name} (${cls.name})`,
                                    })
                                  }
                                  className="p-1 text-slate-400 hover:text-rose-400"
                                  title="حذف الشعبة"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            {/* Section Quick Actions */}
                            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-1.5">
                              <button
                                onClick={() => openSectionGradebook(cls.id, sec.id)}
                                className="flex-1 py-1.5 px-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                              >
                                <Palette className="w-3 h-3" />
                                <span>الدرجات</span>
                              </button>
                              <button
                                onClick={() => openSectionStudents(cls.id, sec.id)}
                                className="flex-1 py-1.5 px-2 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                              >
                                <Users className="w-3 h-3" />
                                <span>الطلبة</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Class Modal */}
      {isAddClassOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161F30] border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-extrabold text-base text-white">
                {editingClass ? 'تعديل اسم الصف' : 'إضافة صف دراسي جديد'}
              </h3>
              <button
                onClick={() => setIsAddClassOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveClass} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اسم الصف الدراسي
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الأول المتوسط"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-teal-400 focus:outline-hidden"
                />

                {/* Suggestions */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {['الأول المتوسط', 'الثاني المتوسط', 'الثالث المتوسط', 'الرابع العلمي', 'الخامس العلمي'].map((sug) => (
                    <button
                      type="button"
                      key={sug}
                      onClick={() => setNewClassName(sug)}
                      className="px-2 py-1 rounded-lg bg-slate-800 text-[11px] text-slate-300 hover:text-teal-300 hover:bg-slate-700 font-medium cursor-pointer"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddClassOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs cursor-pointer"
                >
                  {editingClass ? 'حفظ التعديل' : 'إضافة الصف'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Section Modal */}
      {isAddSectionOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161F30] border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-extrabold text-base text-white">
                {editingSection ? 'تعديل اسم الشعبة' : 'إضافة شعبة جديدة'}
              </h3>
              <button
                onClick={() => setIsAddSectionOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSection} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  اسم أو حرف الشعبة
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: أ / ب / ج"
                  value={newSectionName}
                  onChange={(e) => setNewSectionName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0D131F] border border-slate-700 text-white text-xs focus:border-teal-400 focus:outline-hidden"
                />

                {/* Presets */}
                <div className="flex items-center gap-1.5 mt-2">
                  {['أ', 'ب', 'ج', 'د', 'هـ', 'و'].map((letter) => (
                    <button
                      type="button"
                      key={letter}
                      onClick={() => setNewSectionName(letter)}
                      className={`w-8 h-8 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                        newSectionName === letter
                          ? 'bg-teal-600 text-white border-teal-500'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      {letter}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddSectionOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs cursor-pointer"
                >
                  {editingSection ? 'حفظ التعديل' : 'إضافة الشعبة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#161F30] border border-slate-800 rounded-3xl w-full max-w-sm p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">
                تأكيد حذف {confirmDelete.name}؟
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                سيتم حذف كافة السجلات والطلبة المرتبطين. لا يمكن التراجع.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setConfirmDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  if (confirmDelete.type === 'class') {
                    deleteClass(confirmDelete.id);
                  } else {
                    deleteSection(confirmDelete.id);
                  }
                  setConfirmDelete(null);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
