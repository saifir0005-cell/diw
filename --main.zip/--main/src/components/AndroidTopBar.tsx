import React from 'react';
import {
  Palette,
  Settings as SettingsIcon,
  Code2,
  Calendar,
  Sparkles,
  School,
  User,
  ShieldAlert,
  Award,
  TrendingUp,
} from 'lucide-react';
import { useTeacherApp } from '../context/TeacherAppContext';
import { formatIraqiDate, formatHijriDate } from '../utils/dateUtils';

export const AndroidTopBar: React.FC = () => {
  const { profile, activeScreen, setActiveScreen, compliances } = useTeacherApp();

  const todayGregorian = formatIraqiDate(new Date());
  const todayHijri = formatHijriDate(new Date());

  const nonCompliantCount = React.useMemo(() => {
    return Object.values(compliances).filter((c) => c.totalDeduction > 0).length;
  }, [compliances]);

  return (
    <header className="sticky top-0 z-30 bg-[#111827]/95 backdrop-blur-md border-b border-slate-800 shadow-md print:hidden">
      <div className="px-4 py-3 sm:px-6 flex items-center justify-between gap-4">
        {/* App & Teacher Identity */}
        <div
          onClick={() => setActiveScreen('dashboard')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-teal-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-sky-500/20 shrink-0 group-hover:scale-105 transition-transform">
            <Palette className="w-5 h-5" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-sm sm:text-base text-white tracking-wide">
                سجلي المدرسي
              </h1>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-950 text-sky-300 border border-sky-800/80">
                {profile.academicYear}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="font-bold text-sky-400">{profile.teacherName}</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400 truncate max-w-[180px] sm:max-w-none">
                {profile.schoolName}
              </span>
            </div>
          </div>
        </div>

        {/* Date and Quick Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Screen Shortcuts */}
          <button
            onClick={() => setActiveScreen('non_compliance')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer relative ${
              activeScreen === 'non_compliance'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'text-slate-400 hover:text-rose-300 hover:bg-rose-950/30'
            }`}
            title="قسم غير الملتزم"
          >
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span className="hidden lg:inline">غير الملتزم</span>
            {nonCompliantCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-black flex items-center justify-center">
                {nonCompliantCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveScreen('gifted_students')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeScreen === 'gifted_students'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-amber-300 hover:bg-amber-950/30'
            }`}
            title="الطلبة الموهوبين"
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span className="hidden lg:inline">الموهوبين</span>
          </button>

          <button
            onClick={() => setActiveScreen('statistics')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeScreen === 'statistics'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                : 'text-slate-400 hover:text-indigo-300 hover:bg-indigo-950/30'
            }`}
            title="الإحصائيات ومستويات التحصيل"
          >
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span className="hidden lg:inline">الإحصائيات</span>
          </button>

          <div className="hidden xl:flex flex-col text-left text-[11px] text-slate-400 pl-2 pr-1 border-r border-slate-800">
            <span className="font-semibold text-slate-200">{todayGregorian}</span>
            <span className="text-amber-400/90 text-[10px]">{todayHijri}</span>
          </div>

          <button
            onClick={() => setActiveScreen('android_code')}
            className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeScreen === 'android_code'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="مشروع أندرويد (Kotlin Jetpack Compose)"
          >
            <Code2 className="w-4 h-4 text-teal-400" />
            <span className="hidden sm:inline">Android</span>
          </button>

          <button
            onClick={() => setActiveScreen('settings')}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              activeScreen === 'settings'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="الإعدادات"
          >
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
